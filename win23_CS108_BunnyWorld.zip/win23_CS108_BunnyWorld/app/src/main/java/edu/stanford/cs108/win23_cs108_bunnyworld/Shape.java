package edu.stanford.cs108.win23_cs108_bunnyworld;

import android.graphics.Bitmap;
import android.graphics.Color;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Arrays;

public class Shape implements Serializable {
    static int n_created = 0;
    private String shapeName;                // name of this shape, default Shape1, Shape2
    private String pageName;
    private String imageName;           // image file name to open
    private String text;
    private float textFont = 60f;
    private boolean isBold = false;
    private  boolean isItalic = false;

    // I added (a new thing):
    private boolean ifHasLittleBlackBox;

    private boolean isBorderGreen;
    private boolean isBorderBlue;
    private int textColorRedValue;
    private int textColorGreenValue;
    private int textColorBlueValue;



    private boolean isInPossessionArea;

    private boolean isRect = true;

    private boolean isImage = false;
    private boolean isText = false;	// if both have image and text, only show text

    // to locate this shape in inventory area: coordinate of its bounding rectangle
    private float left;
    private float top;
    private float width;
    private float height;

    private boolean isVisible;
    private boolean isMovable;

    private Set<String> acceptableShapeNames = new HashSet<>();  // set of shapes that I can accept
    private String script;      // sequence of clauses separated by semicolon

    // store list of lists of effects associated with onClick and onEnter respectively:
    // each effect as a separate String (user can add multiple scripts and delete them)

    public ArrayList<ArrayList<String>> onClickEffects = new ArrayList<>();
    public ArrayList<ArrayList<String>> onEnterEffects = new ArrayList<>();

    // store map of effects of onDrop: key = name of Shape drop on me, val = list of string of effects
    public HashMap<String, List<List<String>>> onDropEffects = new HashMap<>();

    private Bitmap shapeBitmap;



    // Constructor
    public Shape(String name, String pageName, boolean visible, boolean movable, String imageName,
                 String text, float textFont, boolean bold, boolean italic) {
        // default front size: 60f
        this.shapeName = name;
        this.pageName = pageName;
        this.isVisible = visible;
        this.isMovable = movable;
        this.imageName = imageName;
        this.text = text;
        this.textFont = textFont;
        this.isBold = bold;
        this.isItalic = italic;

        this.isInPossessionArea = true;

        // default text color opaque black
        textColorRedValue = 0;
        textColorGreenValue = 0;
        textColorBlueValue = 0;
        isBorderGreen = false;
        isBorderBlue = false;

        if (!text.equals("")){
            this.isText = true;
        }
        if (!imageName.equals("")){
            this.isImage = true;
        }

        // when a shape is firstly created, it will appear in the possession area
        this.left = 0.f;
        this.top = 1050.f;


    }


    /*
     * Setters
     * */

    /*
     * Delete an existing onClick, onEnter, or onDrop script (for onClick and onEnter event calls,
     * put None for parameter shapeDropOnMe).
     * */
    public void deleteExistingScript(String event, int index, String shapeDropOnMe ){

        switch (event) {
            case "onClick":
                onClickEffects.remove(index);
                break;
            case "onEnter":
                onEnterEffects.remove(index);
                break;
            case "onDrop":
                onDropEffects.get(shapeDropOnMe).remove(index);
                if (onDropEffects.get(shapeDropOnMe).size() == 0){
                    acceptableShapeNames.remove(shapeDropOnMe);
                }
                break;
        }
        updateScript();

    }



    /*
     * Add a new onClick, onEnter, or onDrop Clause, (for onClick and onEnter event calls,
     * put None for parameter shapeDropOnMe).
     * */
    public void addScript(String event, String goTo, String play, String hide, String show, String shapeDropOnMe ){
        ArrayList<String> newEffect = new ArrayList<>();     // list of single effect strings
        if (goTo != null){
            newEffect.add("goto" + " " + goTo);
        }
        if (play != null) {
            newEffect.add("play" + " " + play);
        }
        if (hide != null) {
            newEffect.add("hide" + " " + hide);
        }
        if (show != null) {
            newEffect.add("show" + " " + show);
        }
        switch (event) {
            case "onClick":
                onClickEffects.add(newEffect);

                break;
            case "onEnter":
                onEnterEffects.add(newEffect);

                break;
            case "onDrop":
                if (onDropEffects.containsKey(shapeDropOnMe)){
                    onDropEffects.get(shapeDropOnMe).add(newEffect);
                } else {
                    List<List<String>> newL = new ArrayList<>();
                    newL.add(newEffect);
                    onDropEffects.put(shapeDropOnMe, newL);
                }

                acceptableShapeNames.add(shapeDropOnMe);
                break;
        }
        updateScript();

    }

    /*
     * Helper: combine lists of Action Effects to a block of script texts, update instance variable script
     * */
    public void updateScript(){
        StringBuilder newScript = new StringBuilder();
        String clickPrefix = new String("on click");
        String enterPrefix = new String("on enter");
        String dropPrefix = new String("on drop");
        for (int i = 0; i < onClickEffects.size(); i++){
            if (i == 0){
                newScript.append(clickPrefix);
            }
            for (int j = 0; j < onClickEffects.get(i).size(); j++){
                newScript.append(" ").append(onClickEffects.get(i).get(j));

            }

            if (i == onClickEffects.size() - 1){
                newScript.append(";");
            }
        }

        for (int i = 0; i < onEnterEffects.size(); i++){
            if (i == 0){
                newScript.append(enterPrefix);
            }
            for (int j = 0; j < onEnterEffects.get(i).size(); j++){
                newScript.append(" ").append(onEnterEffects.get(i).get(j));
            }

            if (i == onEnterEffects.size() - 1){
                newScript.append(";");
            }
        }


        for (Map.Entry<String,List<List<String>>> mapElement: onDropEffects.entrySet()) {
            // loop through list of lists of effects for all different dropOnMe shape
            String dropOnMe = mapElement.getKey();
            List<List<String>> effectLists = mapElement.getValue();
            for (int i = 0; i < effectLists.size(); i++){
                if (i == 0){
                    newScript.append(dropPrefix).append(" ").append(dropOnMe);
                }
                for (int j = 0; j < effectLists.get(i).size(); j++){
                    newScript.append(" ").append(effectLists.get(i).get(j));

                }
                if (i == effectLists.size() - 1){
                    newScript.append(";");
                }
            }
        }
        this.script = newScript.toString();
    }

    public void editSize(float left, float top, float width, float height){
        this.left = left;
        this.top = top;
        this.width = width;
        this.height = height;
    }


    public void setShapeName(String name){
        this.shapeName = name;
        // need to update all other shapes' scripts that contains current shape name
    }

    /*
     * Helper: called when some other shape changes its name, so reference to that shape in
     * this shape's script needs to be updated. References to other shape names appear in "hide",
     * "show", and "on drop" clauses
     * */
    public void editNameInScripts(String oldName, String newName){
        for (int i = 0; i < onClickEffects.size(); i++){
            for (int j = 0; j < onClickEffects.get(i).size(); j++){
                String[] splitted = onClickEffects.get(i).get(j).split(" ");
                if (splitted[0].equals("hide") || splitted[0].equals("show")){
                    if (splitted.length == 2 && splitted[1].equals(oldName)){
                        splitted[1] = newName;
                        StringBuffer newClause = new StringBuffer();
                        for(int k = 0; k < splitted.length; k++) {
                            newClause.append(splitted[k]);
                        }
                        onClickEffects.get(i).set(j, newClause.toString());
                    }
                }
            }
        }

        for (Map.Entry<String,List<List<String>>> mapElement: onDropEffects.entrySet()) {
            // loop through list of lists of effects for all different dropOnMe shape
            String dropOnMe = mapElement.getKey();
            List<List<String>> effectLists = mapElement.getValue();
            if (dropOnMe.equals(oldName)) {
                Object obj = onDropEffects.remove(oldName);
                onDropEffects.put(newName, (List<List<String>>) obj);
            }
        }

        updateScript();

    }

    public void setPageName(String pageName) {
        this.pageName = pageName;
    }

    public void setTextFont(float textFont) {
        this.textFont = textFont;
    }

    public void setText(String text) {
        this.text = text;
        if(!text.equals("")){
            this.isText = true;
        }else{
            this.isText = false;
        }


    }

    public void setBold(boolean bold) {
        isBold = bold;
    }

    public void setItalic(boolean italic) {
        isItalic = italic;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
        if(!imageName.equals("")){
            this.isImage = true;
        }else{
            this.isImage = false;
        }

    }

    public void setIsMovable(boolean b) {
        isMovable = b;
    }

    public void setIsVisible(boolean a) {
        isVisible = a;
    }

    public void setIsBorderGreen(boolean a) {
        isBorderGreen = a;
    }

    public void setIsBorderBlue(boolean a) {
        isBorderBlue = a;
    }

    public void setIfHasLittleBlackBox(boolean c) { ifHasLittleBlackBox = c; }

    public void setWidth(float width) {
        this.width = width;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public void setLeft(float left) {
        this.left = left;
    }

    public void setTop(float top) {
        this.top = top;
    }

    /*
    * setScript() needs to be called when reading Shapes from database.
    * migrate all effects in script to onClickEffects, onEnterEffects, onDropEffects, and
      acceptableShapeNames
    * */
    public void setScript(String script) {
        this.script = script;
        // Assume input script is a valid script
        String[] clauses = script.split(";");
        ArrayList<String> actions = new ArrayList<String>(
                Arrays.asList("goto",
                        "play",
                        "hide",
                        "show"));
        for (String clause: clauses){
            String[] words = clause.split(" ");
            if (words.length < 3){
                continue;           // stop process current clause
            }
            String trigger = words[0] + words[1];
            int start_i = 2;
            String dropOnMe = "";
            if (trigger.equals("ondrop")){
                if (words.length < 4){
                    continue;       // stop process current clause, no valid object
                }
                dropOnMe = words[2];
                start_i++;
            }

            String cur_action = "";

            // deal with current clause word by word
            ArrayList<String> onClickL = new ArrayList<>();
            ArrayList<String> onEnterL = new ArrayList<>();
            String acceptObject = "";
            ArrayList<String> onDropL = new ArrayList<>();
            for (int i = start_i; i < words.length; i++){
                String cur = words[i];
                if (actions.contains(cur)){
                    cur_action = cur;
                } else {
                    if (cur_action.equals("")){         //error checking: no action before object
                        continue;
                    }
                    // cur is the object for cur_action
                    if (trigger.equals("ondrop")){
                        acceptObject = dropOnMe;
//                        acceptableShapeNames.add(dropOnMe);
//                        if (onDropEffects.containsKey(dropOnMe)){
//                            onDropEffects.get(dropOnMe).add(new ArrayList<>(Arrays.asList(cur_action +
//                                    " " + cur)));
//
//                        } else {
//                            List<List<String>> newL = new ArrayList<>();
//                            newL.add(new ArrayList<>(Arrays.asList(cur_action + " " + cur)));
//                            onDropEffects.put(dropOnMe, newL);
//                        }
                        onDropL.add(cur_action + " " + cur);

                    } else if (trigger.equals("onclick")) {
//                        onClickEffects.add(new ArrayList<>(Arrays.asList(cur_action + " " + cur)));
                        onClickL.add(cur_action + " " + cur);

                    } else if ((trigger.equals("onenter"))) {
//                        onEnterEffects.add(new ArrayList<>(Arrays.asList(cur_action + " " + cur)));
                        onEnterL.add(cur_action + " " + cur);

                    }
                    // reset cur_action, assume don't allow multiple objects after one action
                    cur_action = "";


                }


            }
            if (!acceptObject.equals("")) {
                List<List<String>> newL = new ArrayList<>();
                newL.add(onDropL);
                onDropEffects.put(acceptObject, newL);
            }
            if (!onEnterL.isEmpty()){
                onEnterEffects.add(onEnterL);
            }
            if (!onClickL.isEmpty()){
                onClickEffects.add(onClickL);
            }

        }


    }

    public void setInPossessionArea(boolean inPossessionArea) {
        isInPossessionArea = inPossessionArea;
    }

    public void setIsImage(boolean a) {
        isImage = a;
    }

    public void setIsText(boolean b) {
        isText = b;
    }

    public void setIsRect(boolean c) {
        isRect = c;
    }


    /*
     * Getters
     * */

    // possible keys: "onClick", "onEnter", "onDrop shapeName1", "onDrop shapeName2"...
    public Map<String, List<String>> getInfoMap(){
        Map<String, List<String>> infoMap = new HashMap<String, List<String>>();
        // unwrap list of lists to a single list
        List<String> newClickList = new ArrayList<>();
        for (int i = 0; i < onClickEffects.size(); i ++){
            newClickList.addAll(onClickEffects.get(i));
        }
        infoMap.put("onClick", newClickList);


        List<String> newEnterList = new ArrayList<>();
        for (int i = 0; i < onEnterEffects.size(); i ++){
            newEnterList.addAll(onEnterEffects.get(i));
        }
        infoMap.put("onEnter", newEnterList);


        for (Map.Entry<String,List<List<String>>> mapElement: onDropEffects.entrySet()) {
            String dropOnMe = mapElement.getKey();
            List<List<String>> effectLists = mapElement.getValue();

            List<String> newDropList = new ArrayList<>();
            for (int i = 0; i < effectLists.size(); i ++){
                newDropList.addAll(effectLists.get(i));
            }
            infoMap.put("onDrop" + " " + dropOnMe, newDropList);

        }

        return infoMap;

    }
    public String getShapeName() {
        return shapeName;
    }

    public String getPageName() {
        return pageName;
    }

    public String getImageName() {
        return imageName;
    }

    public String getText() {
        return text;
    }

    public float getTextFont() {
        return textFont;
    }



    public int[] getTextColorIntRGBValues() {
        return new int[]{textColorRedValue, textColorGreenValue, textColorBlueValue};
    }

    public boolean getIsRect() {
        return isRect;
    }

    public boolean getIsImage() {
        return isImage;
    }

    public boolean getIsText() {
        return isText;
    }

    public float getLeft() {
        return left;
    }



    public float getTop() {
        return top;
    }



    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public boolean getIsBorderGreen() {
        return isBorderGreen;
    }

    public boolean getIsBorderBlue() {
        return isBorderBlue;
    }

    public boolean getIfHasLittleBlackBox() { return ifHasLittleBlackBox; }

    public boolean getIsInPossessionArea () {
        return isInPossessionArea;
    }
    public boolean getIsVisible() {
        return isVisible;
    }



    public boolean getIsMovable() {
        return isMovable;
    }


    public boolean getIsBold() {
        return isBold;
    }

    public boolean getIsItalic() {
        return isItalic;
    }

    public String getScript() {
        return script;
    }

    // return the names of the set of shapes that can drop on me
    public Set<String> getAcceptableShapeNames(){
        return acceptableShapeNames;
    }


    public void setShapeBitmap(Bitmap bitmap) { shapeBitmap = bitmap; }
    public Bitmap getShapeBitmap() { return shapeBitmap; }


    public Map<String, List<String>> getMagicalMap() {
        Map<String, List<String>> result = new HashMap<>();
        String stringToBeProcessed = script;
        // System.out.println(script);
        System.out.println(script);


        List<String> onClickActions = new ArrayList<>();
        List<String> onEnterActions = new ArrayList<>();
        List<String> onDropActions = new ArrayList<>();

        String[] clausesArray = stringToBeProcessed.split(";");
        // System.out.println(clausesArray.length);
        if (clausesArray.length == 1 && clausesArray[0].equals("")) {return result;}
        for (String clause: clausesArray) {
            String[] allWordsInThisClause = clause.split(" ");
            System.out.println(allWordsInThisClause[0]);
            System.out.println(allWordsInThisClause[1]);

            String trigger = allWordsInThisClause[0] + " " + allWordsInThisClause[1];
            if (trigger.equals("on click")) {
                addAllActionsToThisList(clause.substring(9), onClickActions);
            } else if (trigger.equals("on enter")) {
                addAllActionsToThisList(clause.substring(9), onEnterActions);
            } else {
                // trigger is "on drop", a special way
                addAllActionsToThisList_special(clause.substring(8), onDropActions);
            }
        }

        // Push these 3 key-value pairs into result (which is to be returned)
        result.put("on click", onClickActions);
        result.put("on enter", onEnterActions);
        result.put("on drop", onDropActions);

        return result;
    }

    private void addAllActionsToThisList(String actions, List<String> destination) {
        int index = 0;
        String[] words = actions.split(" ");
        while (index < words.length - 1) {
            destination.add(words[index] + " " + words[index + 1]);
            index += 2;
        }
    }

    private void addAllActionsToThisList_special(String actions, List<String> destination) {
        int index = 0;
        String[] words = actions.split(" ");
        while (index < words.length - 1) {
//            if (words[index].equals("goto") || words[index].equals("play") || words[index].equals("hide") || words[index].equals("show")) {
//                String thisAction = words[index];
//            } else {
//                destination.add(words[index] + " " + words[index + 1] + " " + words[index + 2]);
//                index += 3;
//            }

            int temp = index + 1;
            while (temp < words.length - 1 && isVerb(words[temp])) {
                destination.add(words[index] + " " + words[temp] + " " + words[temp + 1]);
                temp += 2;
            }
            index = temp;
        }
    }

    private boolean isVerb(String thisString) {
        return thisString.equals("goto") || thisString.equals("play") || thisString.equals("hide") || thisString.equals("show");
    }

}
