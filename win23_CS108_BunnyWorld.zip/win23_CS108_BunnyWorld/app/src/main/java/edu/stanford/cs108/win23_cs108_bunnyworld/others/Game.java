package edu.stanford.cs108.win23_cs108_bunnyworld.others;

import java.util.List;

import edu.stanford.cs108.win23_cs108_bunnyworld.others.Page;

public class Game {

    // Instance variables:
    String gameName;
    List<Page> pageList;

    // Constructor:




}
