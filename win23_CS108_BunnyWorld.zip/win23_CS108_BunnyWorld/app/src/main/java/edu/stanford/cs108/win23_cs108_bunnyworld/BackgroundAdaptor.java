package edu.stanford.cs108.win23_cs108_bunnyworld;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;


// code from https://www.youtube.com/watch?v=hdB9XOJu8rY
public class BackgroundAdaptor extends ArrayAdapter<String> {

    Context context;
    List<String> bksList;

    public BackgroundAdaptor(Context context, List<String> bks) {
        super(context, R.layout.editor, bks);
        this.context = context;
        this.bksList = bks;
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    public View getCustomView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.background_dropdown_item, parent, false);

        TextView bkText = row.findViewById(R.id.bktext);
        ImageView bkImg = row.findViewById(R.id.bkimage);

        bkText.setText(bksList.get(position));

        Resources res = context.getResources();
        String bkName = bksList.get(position);
        int resIdx = res.getIdentifier(bkName, "drawable", context.getPackageName());
        Drawable drawable = res.getDrawable(resIdx);

        bkText.setText(bksList.get(position));
        bkImg.setImageDrawable(drawable);

        return row;
    }
}
