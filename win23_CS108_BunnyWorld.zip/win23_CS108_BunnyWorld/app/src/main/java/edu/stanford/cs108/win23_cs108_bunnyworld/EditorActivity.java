package edu.stanford.cs108.win23_cs108_bunnyworld;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.*;

public class EditorActivity
        extends AppCompatActivity
        implements AdapterView.OnItemSelectedListener, AddShapeDialogFragment.OnInputListener{

//    List<String> pages = Arrays.asList("page1");
    List<String> pages;
    List<String> bks;
    customViewEditor myViewEditor;
    private Map<String, List<Shape>> gameMap_EachPageANDItsShapeList= new HashMap<String, List<Shape>>();
    private List<Shape> shapeList_CurrentPage;
    SQLiteDatabase db;

    private String curPageName;

    private Shape lastObject;           // the last object added by CREATE AN OBJECT/EDIT AN OBJECT
    private Shape selectedObject;
    private String oldObjectName;       // temporary storage for the old shape name when you edit a shape
    public String gameToBeEditted;
    public Spinner spinnerPage;
    public Spinner spinnerBk;
    public String itemPage;
    public List<Shape> lastItemList= new ArrayList<Shape>();
    int addfirst = 0;
    int deletefirst = 0;
    private Map<String, List<Shape>> preMap= new HashMap<String, List<Shape>>();
    private List<String> prePages = new ArrayList<String>();
    public List<Shape> preLastItemList= new ArrayList<Shape>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editor);
        // TODO: call loadExistingGame()


        // when initializing the editor, enter the page1 of the selected game/new game

        // TODO: I added this, making the buttons okay to be clicked
        makeAllButtonsReady();
        // --------------------------------------

        Bundle bundle = getIntent().getExtras();
        gameToBeEditted = bundle.getString("gameToBeEditted");
        curPageName = "Page1";
        lastObject = null;
        selectedObject = null;
        oldObjectName = null;
        pages = new ArrayList<>();
        pages.add("Page1");
        bks = new ArrayList<>();
        bks.add("sky");
        bks.add("forest");
        bks.add("night");
        bks.add("stanford");
        EditText gameNameInput = findViewById(R.id.gamename);
        gameNameInput.setText(gameToBeEditted);

        // IMPORTANT: get the view!!!
        myViewEditor = findViewById(R.id.editorView);

        loadExistingGame();


        spinnerPage = findViewById(R.id.selectpage);
        spinnerPage.setOnItemSelectedListener(this);
        ArrayAdapter adPage = new ArrayAdapter(this,
                android.R.layout.simple_spinner_item,
                pages);
        spinnerPage.setAdapter(adPage);

        adPage.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerBk = findViewById(R.id.selectbackground);
        spinnerBk.setOnItemSelectedListener(this);
        SpinnerAdapter adBk = new BackgroundAdaptor(getApplicationContext(), bks);
        spinnerBk.setAdapter(adBk);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        itemPage = spinnerPage.getSelectedItem().toString();
        goToPage();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    private void makeAllButtonsReady() {
        // ***** "ADD PAGE" button and its onClickListener
        Button btnAddPage = (Button)findViewById(R.id.addpage);
        btnAddPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPage();      // maybe reset database, or start another activity, etc
            }
        });

        // ***** "CHANGE PAGE NAME" button and its onClickListener
        Button btnChangePageName = (Button)findViewById(R.id.changepagename);
        btnChangePageName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changePageName();
            }
        });

        // ***** "APPLY BACKGROUND" button and its onClickListener
        Button btnApplyBKD = (Button)findViewById(R.id.applybackground);
        btnApplyBKD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyBKD();
            }
        });

        // ***** "CREATE AN OBJECT" button and its onClickListener
        Button btnCreateAnObject = (Button)findViewById(R.id.createobj);
        btnCreateAnObject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: should this be v
                createAnObject(v);
            }
        });

        // ***** "EDIT AN OBJECT" button and its onClickListener
        Button btnEditAnObject = (Button)findViewById(R.id.editobj);
        btnEditAnObject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: should this be v
                editAnObject(v);
            }
        });

        // ***** "DELETE LAST OBJECT" button and its onClickListener
        Button btnDeleteLasObject = (Button)findViewById(R.id.deletelastobj);
        btnDeleteLasObject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteLastObject();
            }
        });

        // ***** "PLAY GAME" button and its onClickListener
        Button btnDeleteSelected = (Button)findViewById(R.id.deleteslcobj);
        btnDeleteSelected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteSelected();
            }
        });

        // ***** "DELETE THIS PAGE" button and its onClickListener
        Button btnDeleteThisPage = (Button)findViewById(R.id.deletethispage);
        btnDeleteThisPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deletePage();
            }
        });

        // ***** "SAVE GAME" button and its onClickListener
        Button btnSaveGame = (Button)findViewById(R.id.savegame);
        btnSaveGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // for (Shape i: shapeList_CurrentPage) System.out.println(i.getShapeName());
                saveGame();
            }
        });

        Button undoPageBtn = (Button) findViewById(R.id.undoPage);
        undoPageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                undoPage();
            }
        });

    }



    private void loadExistingGame(){
        db = openOrCreateDatabase("ShapesDB", MODE_PRIVATE,null);

        // Get all pages of this game:
        String pageCmd = "SELECT pageName FROM Shapes where gameName = '" + gameToBeEditted + "';";
        Cursor pageCursor = db.rawQuery( pageCmd,null);
        while (pageCursor.moveToNext()) {
            String pageNow = pageCursor.getString(0);
            // Get all shapes in this page of this game
            String shapeCmd = "SELECT * FROM Shapes where gameName = '" +
                    gameToBeEditted + "' AND pageName = '" + pageNow + "';";
            Cursor shapeCursor = db.rawQuery( shapeCmd,null);
            List<Shape> shapesNow = new ArrayList<Shape>();
            while (shapeCursor.moveToNext()) {
                String shapeName = shapeCursor.getString(0);
                String imageName = shapeCursor.getString(1);
                String text = shapeCursor.getString(2);
                float x = shapeCursor.getFloat(3);
                float y = shapeCursor.getFloat(4);
                float width = shapeCursor.getFloat(5);
                float height = shapeCursor.getFloat(6);
                Integer isPossesion_ = shapeCursor.getInt(7);
                Integer isBold_ = shapeCursor.getInt(8);
                Integer isItalic_ = shapeCursor.getInt(9);
                Integer movable_ = shapeCursor.getInt(10);
                Integer isVisible_ = shapeCursor.getInt(11);
                Integer fontSize = shapeCursor.getInt(12);
                String script = shapeCursor.getString(13);
                String pageName = shapeCursor.getString(14);
                Boolean isPossesion = isPossesion_ == 0 ? false : true;
                Boolean isBold = isBold_ == 0 ? false : true;
                Boolean isItalic = isItalic_ == 0 ? false : true;
                Boolean movable = movable_ == 0 ? false : true;
                Boolean isVisible = isVisible_ == 0 ? false : true;
                Shape shapeNow = new Shape(shapeName, pageName, isVisible, movable, imageName, text, fontSize, isBold, isItalic);
                shapeNow.setLeft(x);
                shapeNow.setTop(y);
                shapeNow.setWidth(width);
                shapeNow.setHeight(height);
                shapeNow.setScript(script);
                shapeNow.setInPossessionArea(isPossesion);
                shapesNow.add(shapeNow);
            }
            gameMap_EachPageANDItsShapeList.put(pageNow, shapesNow);
        }
        shapeList_CurrentPage = gameMap_EachPageANDItsShapeList.get("Page1");
        for (String cur: gameMap_EachPageANDItsShapeList.keySet()) {
            if (!cur.equals("Page1")) {
                pages.add(cur);
            }
        }
        // Sort the pages:
        Collections.sort(pages);
        if (shapeList_CurrentPage != null) {
            myViewEditor.drawCurrentPage(shapeList_CurrentPage);
        } else {
            List<Shape> newPageOne = new ArrayList<Shape>();
            gameMap_EachPageANDItsShapeList.put("Page1", newPageOne);    // new a new page;
            myViewEditor.drawCurrentPage(newPageOne);
        }
    }

    private void saveGame () {
        db = openOrCreateDatabase("ShapesDB", MODE_PRIVATE,null);
        String deleteOriginalCMD = "DELETE FROM Shapes WHERE gameName = '" + gameToBeEditted + "';";
        db.execSQL(deleteOriginalCMD);
        EditText name = findViewById(R.id.gamename);
        String nameOfGame = name.getText().toString(); ///////////
// Get all pages of this game:
        String nameCMD = "SELECT * FROM Shapes where gameName = '" + nameOfGame + "';";
        Cursor nameCursor = db.rawQuery(nameCMD,null);
        if (nameOfGame.equals("")) {
            Toast toast = Toast.makeText(
                    getApplicationContext(),
                    "Please enter a name for your game!",
                    Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        else if (!nameOfGame.equals(gameToBeEditted) && nameCursor.getCount() != 0) {
            Toast toast = Toast.makeText(
                    getApplicationContext(),
                    "Game name already exist!",
                    Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        else if (gameToBeEditted.equals("DefaultGame") && !nameOfGame.equals(gameToBeEditted)){
            Toast toast = Toast.makeText(
                    getApplicationContext(),
                    "Cannot rename the default game!",
                    Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        for (String pageNameToBeSaved: gameMap_EachPageANDItsShapeList.keySet()) {
            for (Shape shapeToBeSaved: gameMap_EachPageANDItsShapeList.get(pageNameToBeSaved)) {
                String shapeToBeSaved_name = shapeToBeSaved.getShapeName();
                String shapeToBeSaved_shape = shapeToBeSaved.getImageName();
                String shapeToBeSaved_text = shapeToBeSaved.getText();
                Float shapeToBeSaved_x = shapeToBeSaved.getLeft();
                Float shapeToBeSaved_y = shapeToBeSaved.getTop();
                Float shapeToBeSaved_width = shapeToBeSaved.getWidth();
                Float shapeToBeSaved_height = shapeToBeSaved.getHeight();
                Integer shapeToBeSaved_inP = shapeToBeSaved.getIsInPossessionArea() ? 1 : 0;
                Integer shapeToBeSaved_isBold = shapeToBeSaved.getIsBold() ? 1 : 0;
                Integer shapeToBeSaved_isItalic = shapeToBeSaved.getIsItalic() ? 1 : 0;
                Integer shapeToBeSaved_isMovable = shapeToBeSaved.getIsMovable() ? 1 : 0;
                Integer shapeToBeSaved_isVisible = shapeToBeSaved.getIsVisible() ? 1 : 0;
                Float shapeToBeSaved_fontSize = shapeToBeSaved.getTextFont();
                String shapeToBeSaved_script = shapeToBeSaved.getScript();
                String shapeToBeSaved_pageName = shapeToBeSaved.getPageName();
                String shapeToBeSaved_gameName = nameOfGame;
                String cmd = "INSERT INTO Shapes VALUES ('" +
                        shapeToBeSaved_name + "', '" +
                        shapeToBeSaved_shape + "', '" +
                        shapeToBeSaved_text + "', '" +
                        shapeToBeSaved_x + "', '" +
                        shapeToBeSaved_y + "', '" +
                        shapeToBeSaved_width + "', '" +
                        shapeToBeSaved_height + "', '" +
                        shapeToBeSaved_inP + "', '" +
                        shapeToBeSaved_isBold + "', '" +
                        shapeToBeSaved_isItalic + "', '" +
                        shapeToBeSaved_isMovable + "', '" +
                        shapeToBeSaved_isVisible + "', '" +
                        shapeToBeSaved_fontSize + "', '" +
                        shapeToBeSaved_script + "', '" +
                        shapeToBeSaved_pageName + "', '" +
                        shapeToBeSaved_gameName + "',  NULL);";
                db.execSQL(cmd);
            }
        }
        Toast.makeText(getApplicationContext(), nameOfGame + " saved to DB!", Toast.LENGTH_SHORT).show();
        finish();
    }

    /*
        Clicking the "CREATE AN OBJECT" button will calling the Add Shape Dialog.
     */
    public void createAnObject(View view) {
        AddShapeDialogFragment addshapedialogfragment = new AddShapeDialogFragment();
        Bundle bundle = new Bundle();
        String mode = "create";
        String currPage = curPageName;
        ArrayList<String> pageNames = new ArrayList<>(gameMap_EachPageANDItsShapeList.keySet());
        ArrayList<String> shapeNames = new ArrayList<>();           // will contain all the shape in this game
        for (String pageName : gameMap_EachPageANDItsShapeList.keySet()) {
            if (gameMap_EachPageANDItsShapeList.get(pageName) != null) {
                for (Shape shape : gameMap_EachPageANDItsShapeList.get(pageName)) {
                    shapeNames.add(shape.getShapeName());
                }
            }
        }
        // to support the undo page action, must check if a shape name is repeated in preMap
        ArrayList<String> preMapShapeNames = new ArrayList<>();
        for (String pageName : preMap.keySet()) {
            if (preMap.get(pageName) != null) {
                for (Shape shape : preMap.get(pageName)) {
                    preMapShapeNames.add(shape.getShapeName());
                }
            }
        }

        // initialize a shape which is going to be modified by the user through the dialog
        // after modification, the modified Shape will be passed back to the EditorActivity
        Shape newShape = new Shape("", currPage, true, true, "", "", 12.0f, false, false);
        bundle.putString("mode", mode);
        bundle.putString("currPageName", currPage);
        bundle.putSerializable("pageNames", pageNames);
        bundle.putSerializable("shapeNames", shapeNames);
        bundle.putSerializable("theShape", newShape);
        bundle.putSerializable("preMapShapeNames", preMapShapeNames);
        addshapedialogfragment.setArguments(bundle);
        addshapedialogfragment.show(getSupportFragmentManager(), "Add Shape Dialog");

        // myViewEditor.drawCurrentPage(gameMap_EachPageANDItsShapeList.get(currPage));
    }

    public void editAnObject(View view) {
        if (selectedObject == null) {
            Toast.makeText(getApplicationContext(), "Please Select an object!", Toast.LENGTH_SHORT).show();
            }
        else if (bks.contains(selectedObject.getImageName())) {
            Toast.makeText(getApplicationContext(), "Cannot edit the background!", Toast.LENGTH_SHORT).show();
        }
        else {
            oldObjectName = selectedObject.getShapeName();
            // edit the selected shape on the screen!
            AddShapeDialogFragment addshapedialogfragment = new AddShapeDialogFragment();
            Bundle bundle = new Bundle();
            String mode = "edit";
            // these args are just for testing purpose
            String currPage = curPageName;
            ArrayList<String> pageNames = new ArrayList<>(gameMap_EachPageANDItsShapeList.keySet());
            ArrayList<String> shapeNames = new ArrayList<>();
            for (String pageName : gameMap_EachPageANDItsShapeList.keySet()) {
                for (Shape shape : gameMap_EachPageANDItsShapeList.get(pageName)) {
                    if (!shape.getShapeName().equals(selectedObject.getShapeName())) {      // excluding the shape that is being edited
                        shapeNames.add(shape.getShapeName());
                    }
                }
            }
            ArrayList<String> preMapShapeNames = new ArrayList<>();
            for (String pageName : preMap.keySet()) {
                for (Shape shape : preMap.get(pageName)) {
                    if (!shape.getShapeName().equals(selectedObject.getShapeName())) {      // excluding the shape that is being edited
                        preMapShapeNames.add(shape.getShapeName());
                    }
                }
            }
            bundle.putString("mode", mode);
            bundle.putString("currPageName", currPage);
            bundle.putSerializable("pageNames", pageNames);
            bundle.putSerializable("shapeNames", shapeNames);
            bundle.putSerializable("theShape", selectedObject);
            bundle.putSerializable("preMapShapeNames", preMapShapeNames);
            addshapedialogfragment.setArguments(bundle);
            addshapedialogfragment.show(getSupportFragmentManager(), "Edit Shape Dialog");
        }
    }


    @Override
    public void sendInput(String mode, Shape newShape) {
        if (mode.equals("create")) {
            // these following prints are just for debug purpose!
            System.out.println("shapeName: " + newShape.getShapeName());
            System.out.println("imageName: " + newShape.getImageName());
            System.out.println("textContent: " + newShape.getText());
            System.out.println("Script: " + newShape.getScript());
            // save the returned newShape to DB;
            gameMap_EachPageANDItsShapeList.get(curPageName).add(newShape);
            lastItemList.add(newShape);
        }
        if (mode.equals("edit")) {
            String oldShapeName = selectedObject.getShapeName();
            System.out.println("SHAPE EDITTED!!");
            System.out.println("shapeName: " + newShape.getShapeName());
            System.out.println("imageName: " + newShape.getImageName());
            System.out.println("textContent: " + newShape.getText());
            System.out.println("Script: " + newShape.getScript());
            // delete the current selectedObject and add the newShape to DB
            gameMap_EachPageANDItsShapeList.get(curPageName).add(newShape);
            gameMap_EachPageANDItsShapeList.get(curPageName).remove(selectedObject);
            if (!newShape.getShapeName().equals(oldObjectName)) {
                // update all shape's script if any of them contains the old selectedObject name.
                for (String key: gameMap_EachPageANDItsShapeList.keySet()) {
                    List<Shape> shapeList = gameMap_EachPageANDItsShapeList.get(key);
                    List<Shape> newShapeList = renameShapeUpdateScripts(shapeList, oldObjectName, newShape.getShapeName());
                    gameMap_EachPageANDItsShapeList.put(key, newShapeList);
                }
            }
            lastItemList.remove(selectedObject);
            lastItemList.add(newShape);
        }
        myViewEditor.drawCurrentPage(gameMap_EachPageANDItsShapeList.get(curPageName));
    }
    private void addPage () {
        EditText newNameText = findViewById(R.id.pagename);
        String newPageName = newNameText.getText().toString();
//        pages.
        // pages.add(newPageName);
        System.out.println(pages.size());
        for (String cur:pages) {
            if (cur.equals(newPageName)) {
                Toast toast = Toast.makeText(
                        getApplicationContext(),
                        "This page name is used!",
                        Toast.LENGTH_SHORT);
                toast.show();
                return;
            }
        }
        addfirst = 1;
        deletefirst = 0;
        prePages.clear();
        preMap.clear();
        for (String cur: gameMap_EachPageANDItsShapeList.keySet()) {
            preMap.put(cur, gameMap_EachPageANDItsShapeList.get(cur));
        }
        for (String cur:pages) {
            prePages.add(cur);
        }
        pages.add(newPageName);
        List<Shape> newShapes = new ArrayList<Shape>();
        gameMap_EachPageANDItsShapeList.put(newPageName, newShapes);
        curPageName = newPageName;
        int pagePosition = pages.indexOf(curPageName);
        if (pagePosition != -1) {
            spinnerPage.setSelection(pagePosition);
        }
        System.out.println(newPageName);
        myViewEditor.drawCurrentPage(newShapes);
    }

    private void goToPage () {
        String toPage = itemPage;
        List<Shape> shapesOfNewPage = gameMap_EachPageANDItsShapeList.get(toPage);
        ///Check whether new page has an on enter effect
        curPageName = toPage;
        myViewEditor.drawCurrentPage(shapesOfNewPage);
    }


    // TODO - 1: get the single selected shape from the MOTION_DOWN event
    //      in the overridden onTouchEvent() method located in customViewEditor
    public void getSelected (Shape a) {
        selectedObject = a;
    }

    // TODO - 2: renew the position of the shape
    //      Get the shapeList on current page before everything is drawn by onDraw() event
    //      I added this at the end of the overridden onTouchEvent() method located in customViewEditor
    public void renewShape (List<Shape> a) {
        gameMap_EachPageANDItsShapeList.remove(curPageName);
        gameMap_EachPageANDItsShapeList.put(curPageName, a);
        // 
    }

    private void deleteLastObject () {
        ////define a cur page
        //define a last object
        if (lastItemList.size() == 0) {
            Toast toast = Toast.makeText(
                    getApplicationContext(),
                    "No object to be deleted!",
                    Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        Shape lastObject = lastItemList.get(lastItemList.size() - 1);
        String pageNameOfLastObject = lastObject.getPageName();
        lastItemList.remove(lastObject);
        gameMap_EachPageANDItsShapeList.get(pageNameOfLastObject).remove(lastObject);
        List<Shape> deletedShapeOfPage = gameMap_EachPageANDItsShapeList.get(pageNameOfLastObject);
        if (lastObject.getPageName().equals(curPageName)) {
            myViewEditor.drawCurrentPage(deletedShapeOfPage);
        }
    }

    private void deleteSelected () {
        if (selectedObject == null) {
            Toast toast = Toast.makeText(
                    getApplicationContext(),
                    "Please select an object!",
                    Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        lastItemList.remove(selectedObject);
        String pageNameOfSlectedObject = selectedObject.getPageName();
        gameMap_EachPageANDItsShapeList.get(pageNameOfSlectedObject).remove(selectedObject);
        List<Shape> deletedShapeOfPage = gameMap_EachPageANDItsShapeList.get(pageNameOfSlectedObject);
        if (selectedObject.getPageName().equals(curPageName)) {
            myViewEditor.drawCurrentPage(deletedShapeOfPage);
        }
    }

    private void deletePage () {
        if (curPageName.equals("Page1")) {
            Toast toast = Toast.makeText(
                    getApplicationContext(),
                    "You can not delete Page1!",
                    Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        addfirst = 0;
        deletefirst = 1;
        prePages.clear();
        preMap.clear();
        for (String cur: gameMap_EachPageANDItsShapeList.keySet()) {
            preMap.put(cur, gameMap_EachPageANDItsShapeList.get(cur));
        }
        for (String cur:pages) {
            prePages.add(cur);
        };

        gameMap_EachPageANDItsShapeList.remove(curPageName);
//        int indexToBeDeleted;
//        for (int i = 0; i < pages.size(); i++) {
//            if (pages.get(i) == curPageName) {
//                indexToBeDeleted = i
//                break;
//            }
//        }
        pages.remove(curPageName);
        curPageName = "Page1";
        List<Shape> shapesOfPageOne = gameMap_EachPageANDItsShapeList.get("Page1");
        myViewEditor.drawCurrentPage(shapesOfPageOne);

        spinnerPage.setSelection(((ArrayAdapter<String>)spinnerPage.getAdapter()).getPosition("Page1"));
    }

    private void changePageName () {
        if (curPageName.equals("Page1")) {
            Toast toast = Toast.makeText(
                    getApplicationContext(),
                    "You can not rename Page1!",
                    Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        EditText newNameOfPage = findViewById(R.id.pagename);
        String pageNameToBeChanged = newNameOfPage.getText().toString();
        List<Shape> transfer = gameMap_EachPageANDItsShapeList.get(curPageName);
        // update the "PageName" property of shapes in transfer
        for (Shape s: transfer) {
            s.setPageName(pageNameToBeChanged);
        }
        // in case on this page there's a shape calls goto this page itself
        transfer = renamePageUpdateScripts(transfer, curPageName, pageNameToBeChanged);

        gameMap_EachPageANDItsShapeList.remove(curPageName);
        // if there's any other shape in this game has a script related to the old page name
        for (String key : gameMap_EachPageANDItsShapeList.keySet()) {
            List<Shape> newShapeList = renamePageUpdateScripts(gameMap_EachPageANDItsShapeList.get(key),
                    curPageName, pageNameToBeChanged);
            gameMap_EachPageANDItsShapeList.put(key, newShapeList);
        }
        pages.remove(curPageName);
        pages.add(pageNameToBeChanged);
        curPageName = pageNameToBeChanged;
        // set the spinner content
        int pagePosition = pages.indexOf(curPageName);
        if (pagePosition != -1) {
            spinnerPage.setSelection(pagePosition);
        }
        gameMap_EachPageANDItsShapeList.put(pageNameToBeChanged, transfer);
    }

    /*
    Helper function that updates the scripts in given a list of shapes after a page's name has been changed.
    check if there are some shape's script contains the old name of a page and substitute it to the new name.
     */
    private List<Shape> renamePageUpdateScripts(List<Shape> shapeList, String oldPageName, String newPageName) {
        for (Shape s: shapeList) {
            String oldScript = s.getScript();
            String newScript = oldScript.replaceAll("goto " + oldPageName, "goto " + newPageName);
            s.setScript(newScript);
        }
        return shapeList;
    }

    private List<Shape> renameShapeUpdateScripts(List<Shape> shapeList, String oldShapeName, String newShapeName) {
        for (Shape s: shapeList) {
            String oldScript = s.getScript();
            String newScript = oldScript.replaceAll(oldShapeName, newShapeName);
            s.setScript(newScript);
        }
        return shapeList;
    }

    private void applyBKD () {
        String bkdName = spinnerBk.getSelectedItem().toString();
        Shape bkdShape = new Shape(bkdName + curPageName, curPageName, true, false, bkdName, "", 0, false, false);
        bkdShape.setLeft(0);
        bkdShape.setTop(0);
        bkdShape.setWidth(2560);
        bkdShape.setHeight(1800);
        bkdShape.setScript("");
        bkdShape.setInPossessionArea(false);
        List<Shape> curPageShapes= gameMap_EachPageANDItsShapeList.get(curPageName);
        int saved = 0;
        if (curPageShapes.size() != 0 && bks.contains(curPageShapes.get(0).getImageName())) curPageShapes.remove(0);
        gameMap_EachPageANDItsShapeList.get(curPageName).add(0, bkdShape);
        myViewEditor.drawCurrentPage(gameMap_EachPageANDItsShapeList.get(curPageName));
    }

    private void undoPage() {
        // when undo a add/delete page, always back to page1 of that game
        curPageName = "Page1";
        int pagePosition = pages.indexOf(curPageName);
        if (pagePosition != -1) {
            spinnerPage.setSelection(pagePosition);
        }
        if (addfirst == 0 && deletefirst == 0) {
            Toast toast = Toast.makeText(
                    getApplicationContext(),
                    "No page action detected!",
                    Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        else {
            gameMap_EachPageANDItsShapeList.clear();
            for (String cur: preMap.keySet()) {
                gameMap_EachPageANDItsShapeList.put(cur, preMap.get(cur));
            }
            pages.clear();
            for (String cur:prePages) {
                pages.add(cur);
            }
            addfirst = 0;
            deletefirst = 0;
            myViewEditor.drawCurrentPage(gameMap_EachPageANDItsShapeList.get("Page1"));
        }
    }
}


