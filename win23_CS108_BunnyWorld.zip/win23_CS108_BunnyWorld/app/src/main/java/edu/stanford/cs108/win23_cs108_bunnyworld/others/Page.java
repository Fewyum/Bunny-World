package edu.stanford.cs108.win23_cs108_bunnyworld.others;

import java.util.*;
import android.annotation.SuppressLint;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.view.MotionEvent;
import android.content.*;
import android.graphics.*;
import android.util.*;

import androidx.appcompat.app.AppCompatActivity;

import edu.stanford.cs108.win23_cs108_bunnyworld.Shape;

public class Page extends AppCompatActivity {

    // Instance variables:
    String pageName;
    List<Shape> shapesOnThisPage;

    SQLiteDatabase db;



    // Constructor:
    public Page(String pageName, List<Shape> shapesOnThisPage) {
        this.pageName = pageName;
        this.shapesOnThisPage = shapesOnThisPage;
        db = openOrCreateDatabase("ShapesDB", MODE_PRIVATE,null);
    }


    // Method 1 (add a shape, to this page + into DB):
    private void addShapeToThisPageAndIntoDB(Shape a) {
        String str1 = "INSERT INTO Shapes VALUES ('" +
                allInfoOfThisShape(a).get(0) + "', '" +
                allInfoOfThisShape(a).get(1) + "', '" +
                allInfoOfThisShape(a).get(2) + "', '" +
                allInfoOfThisShape(a).get(3) + "', '" +
                allInfoOfThisShape(a).get(4) + "', '" +
                allInfoOfThisShape(a).get(5) + "', '" +
                allInfoOfThisShape(a).get(6) + "', '" +
                allInfoOfThisShape(a).get(7) + "', '" +
                allInfoOfThisShape(a).get(8) + "', '" +
                allInfoOfThisShape(a).get(9) + "', '" +
                allInfoOfThisShape(a).get(10) + "', '" +
                allInfoOfThisShape(a).get(11) + "', '" +
                allInfoOfThisShape(a).get(12) + "', '" +
                allInfoOfThisShape(a).get(13) + "', '" +
                allInfoOfThisShape(a).get(14) + "', '" +
                allInfoOfThisShape(a).get(15) + "',  NULL);";
        db.execSQL(str1);
        shapesOnThisPage.add(a);
    }

    // Method 2 (delete a shape, from this page + out of DB):
    private void deleteShapeFromThisPageAndOutOfDB(Shape b) {
        String nameOfThisShapeToBeDeleted = b.getShapeName();
        //String itsGameName = b.getGameName();
//        String str2 = "DELETE FROM ShapesDB WHERE " +
//                "shapeName = " + nameOfThisShapeToBeDeleted +
//                " AND gameName = " +  itsGameName + ";";
//        db.execSQL(str2);
        shapesOnThisPage.remove(b);
    }

    // Method 3 (delete last shape just added in):


    // Method 4 (delete all "selected" shapes, the ones with blue border):
    private void deleteAllSelectedShapesFromThisPageAndOutOfDB() {
        for (Shape i: shapesOnThisPage) {
            if (i.getIsBorderGreen()) {
                deleteShapeFromThisPageAndOutOfDB(i);
            }
        }
    }


    // Helper functions:
    private List<String> allInfoOfThisShape(Shape shape) {
        List<String> result = new ArrayList<>();

        result.add(shape.getShapeName());
        result.add(shape.getImageName());
        result.add(shape.getText());
        result.add(String.valueOf(shape.getLeft()));
        result.add(String.valueOf(shape.getTop()));
        result.add(String.valueOf(shape.getWidth()));
        result.add(String.valueOf(shape.getHeight()));

        result.add(String.valueOf(shape.getIsInPossessionArea()));
        result.add(String.valueOf(shape.getIsBold()));
        result.add(String.valueOf(shape.getIsItalic()));
        result.add(String.valueOf(shape.getIsMovable()));
        result.add(String.valueOf(shape.getIsVisible()));

        result.add(String.valueOf(shape.getTextFont()));
        result.add(String.valueOf(shape.getScript()));
        result.add(String.valueOf(shape.getPageName()));
        // result.add(String.valueOf(shape.getGameName()));
        return result;
    }
}



// each page has its shapeList, when onDraw() need to select which shapes to draw
