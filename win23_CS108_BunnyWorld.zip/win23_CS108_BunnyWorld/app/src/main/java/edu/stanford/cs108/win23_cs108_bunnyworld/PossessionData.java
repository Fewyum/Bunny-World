package edu.stanford.cs108.win23_cs108_bunnyworld;

import java.util.ArrayList;
import java.util.List;

public class PossessionData {

    private static PossessionData instance = new PossessionData();  // the only instance of this class

    private List<Shape> shapeList;          // data stored in instance

    private PossessionData(){
        shapeList = new ArrayList<>();
    }

    public PossessionData getInstance(){       // get the only instance of class PossessionData
        return instance;
    }

    public void setList(List<Shape> newList){   // instance function: change list to given list
        shapeList = newList;
    }

    public void addShape(Shape newShape){       // instance method: add shape to list
        shapeList.add(newShape);
    }

}
