package edu.stanford.cs108.win23_cs108_bunnyworld;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentResultListener;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class AddShapeDialogFragment extends AppCompatDialogFragment {
    public OnInputListener addShapeDialogListener;

    private Shape newShape;             // the shape that is going to be built in this dialog
    private String mode;                // indicate whether this dialog is called by "CREATE AN OBJECT" or "EDIT AN OBJECT"
    private String originalShapeName;   // the shapeName when the shape is just inputted to the dialog

    EditText thisShapeName;
    CheckBox visibility, movability;
    Boolean visibleCheck, movableCheck;
    CheckBox imageClass, textClass;
    Spinner imageSpinner;
    String selectedImageName;
    ImageView imagePreview;
    EditText textInput, textSizeInput;
    CheckBox boldText, italicText;
    Boolean boldCheck, italicCheck;
    Spinner onClickGoToSpinner, onClickPlaySpinner, onClickHideSpinner, onClickShowSpinner;
    String onClickGoToScript, onClickPlayScript, onClickHideScript, onClickShowScript;
    Button addOnClickBtn, editOnClickBtn;
    Spinner onEnterGoToSpinner, onEnterPlaySpinner, onEnterHideSpinner, onEnterShowSpinner;
    String onEnterGoToScript, onEnterPlayScript, onEnterHideScript, onEnterShowScript;
    Button addOnEnterBtn, editOnEnterBtn;
    Spinner objectAcceptedSpinner, onDropGoToSpinner, onDropPlaySpinner, onDropHideSpinner, onDropShowSpinner;
    String selectedObjectAcceptedName, onDropGoToScript, onDropPlayScript, onDropHideScript, onDropShowScript;
    Button addOnDropBtn, editOnDropBtn;
    Button saveShapeBtn, cancelBtn;
    Bitmap shapeBitmap;
    BitmapDrawable carrotDrawable;
    BitmapDrawable carrot2Drawable;
    BitmapDrawable deathDrawable;
    BitmapDrawable doorDrawable;
    BitmapDrawable duckDrawable;
    BitmapDrawable fireDrawable;
    BitmapDrawable mysticDrawable;

    // these following 3 ArrayList will be in the EditorActivity!!
    private String currPageName;                            // the page that the shape is in
    public ArrayList<String> shapeNames;                // all available shapes in this game, excluding the one that is being edited
    public ArrayList<String> pageNames;                 // all the pages in this game, including the current page

    public ArrayList<String> preMapShapeNames;

    public final ArrayList<String> DEFAULTIMAGES = new ArrayList<>(Arrays.asList("", "carrot", "carrot2", "death", "door", "duck", "fire", "mystic"));
    public final ArrayList<String> DEFAULTSOUNDS = new ArrayList<>(Arrays.asList("", "carrotcarrotcarrot", "evillaugh", "fire", "hooray", "munch", "munching", "woof"));
    public final Float DEFAULTFONTSIZE = 12.0f;

    // private ArrayList<ArrayList<String>> onClickActions = new ArrayList<>();    // Inner list: <String GoTo, String Play, String Hide, String Show>
    // private ArrayList<ArrayList<String>> onEnterActions = new ArrayList<>();    // will look like <<"page1", "", "", "shape2">, <"", "hooray", "", "winText">>
    // private HashMap<String, ArrayList<ArrayList<String>>> onDropActions = new HashMap<>();



    /*
    Refer to: https://www.geeksforgeeks.org/how-to-pass-data-from-dialog-fragment-to-activity-in-android/
     */
    public interface OnInputListener {
        void sendInput(String mode, Shape newShape);
    }

    @Override
    public void onAttach(@NonNull Context context)
    {
        super.onAttach(context);
        try {
            addShapeDialogListener
                    = (OnInputListener)context;
        }
        catch (ClassCastException e) {
            Log.e("AddShapeDialogFragment", "onAttach: ClassCastException: "
                    + e.getMessage());
        }
    }

//    /*
//    process the information get from the Edit Script Dialog listener -- delete the corresponding scripts in newShape
//     */
//    @Override
//    public void sendDeleteInput(String event, int index, String shapeDropOnMe) {
//        newShape.deleteExistingScript(event, index, shapeDropOnMe);
//    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        assert getArguments() != null;        // <--- quick fixed by android studio
        currPageName = getArguments().getString("currPageName");
        shapeNames = (ArrayList<String>) getArguments().getSerializable("shapeNames");
        shapeNames.add(0, "");              // prepend an empty string at front, in case the user don't want to select anything
        pageNames = (ArrayList<String>) getArguments().getSerializable("pageNames");
        pageNames.add(0, "");
        mode = getArguments().getString("mode");
        newShape = (Shape) getArguments().getSerializable("theShape");
        originalShapeName = newShape.getShapeName();
        preMapShapeNames = (ArrayList<String>) getArguments().getSerializable("preMapShapeNames");

        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        if (mode.equals("create")){
            builder.setTitle("Add An Object!");
        }
        else{                   // edit mode
            builder.setTitle("Edit An Object!");
        }

        final View addShapePopupView = getLayoutInflater().inflate(R.layout.add_shape_popup, null);
        builder.setView(addShapePopupView);

        thisShapeName = addShapePopupView.findViewById(R.id.shapeName);
        visibility = addShapePopupView.findViewById(R.id.visible);
        movability = addShapePopupView.findViewById(R.id.movable);

        // if the shape is movable, delete all of its onClick script.
        movability.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    while (!newShape.onClickEffects.isEmpty()) {
                        newShape.deleteExistingScript("onClick", 0, null);
                    }
                }
            }
        });

        imageClass = addShapePopupView.findViewById(R.id.imageClass);
        imagePreview = addShapePopupView.findViewById(R.id.imagePreview);

        textClass = addShapePopupView.findViewById(R.id.textClass);
        textInput = addShapePopupView.findViewById(R.id.textInput);
        textSizeInput = addShapePopupView.findViewById(R.id.fontSizeInput);
        boldText = addShapePopupView.findViewById(R.id.boldText);
        italicText = addShapePopupView.findViewById(R.id.italicText);

        carrotDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.carrot);
        carrot2Drawable = (BitmapDrawable) getResources().getDrawable(R.drawable.carrot2);
        deathDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.death);
        doorDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.door);
        duckDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.duck);
        fireDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.fire);
        mysticDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.mystic);

        imageSpinner = addShapePopupView.findViewById(R.id.imageSelection);
        if (!newShape.getIsImage()){
            imageSpinner.setEnabled(false);
        }
        onClickPlaySpinner = addShapePopupView.findViewById(R.id.onClickPlay);
        onEnterPlaySpinner = addShapePopupView.findViewById(R.id.onEnterPlay);
        onDropPlaySpinner = addShapePopupView.findViewById(R.id.onDropPlay);
        onClickGoToSpinner = addShapePopupView.findViewById(R.id.onClickGoTo);
        onEnterGoToSpinner = addShapePopupView.findViewById(R.id.onEnterGoTo);
        onDropGoToSpinner = addShapePopupView.findViewById(R.id.onDropGoTo);
        objectAcceptedSpinner = addShapePopupView.findViewById(R.id.objAcceptedSelection);
        onClickShowSpinner = addShapePopupView.findViewById(R.id.onClickShow);
        onEnterShowSpinner = addShapePopupView.findViewById(R.id.onEnterShow);
        onDropShowSpinner = addShapePopupView.findViewById(R.id.onDropShow);
        onClickHideSpinner = addShapePopupView.findViewById(R.id.onClickHide);
        onEnterHideSpinner =  addShapePopupView.findViewById(R.id.onEnterHide);
        onDropHideSpinner = addShapePopupView.findViewById(R.id.onDropHide);
        setSpinners();              // Set Spinners with the correct ArrayAdapter!
        // for the hide & show spinners, the user can select to hide / show the shape itself

        thisShapeName.setText(newShape.getShapeName());
        visibility.setChecked(newShape.getIsVisible());
        movability.setChecked(newShape.getIsMovable());
        imageClass.setChecked(newShape.getIsImage());
        if (newShape.getIsImage()) {
            int imagePosition = DEFAULTIMAGES.indexOf(newShape.getImageName());
            if (imagePosition != -1) {          // if imageName exist in available image name
                imageSpinner.setSelection(imagePosition);
            }
        }
        textClass.setChecked(newShape.getIsText());
        if (newShape.getIsText()) {
            textInput.setText(newShape.getText());
            textSizeInput.setText(String.valueOf((int) newShape.getTextFont()));
            boldText.setChecked(newShape.getIsBold());
            italicText.setChecked(newShape.getIsItalic());
        }

        // enable image selection when (CheckBox) imageCheck is checked
        imageClass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    imageSpinner.setEnabled(true);
                    imagePreview.setEnabled(true);
                } else {
                    imageSpinner.setEnabled(false);
                    imageSpinner.setSelection(0);           // clear the image selection if shape is not image
                    imagePreview.setEnabled(false);
                }
            }
        });

        // enable textInput, textSize, and rich text when (CheckBox) textCheck is checked
        // TODO: add rich text support later
        textClass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    textInput.setEnabled(true);
                    textSizeInput.setEnabled(true);
                    boldText.setEnabled(true);
                    italicText.setEnabled(true);
                } else {
                    textInput.setText(""); textInput.setEnabled(false);
                    textSizeInput.setText(""); textSizeInput.setEnabled(false);
                    boldText.setChecked(false); boldText.setEnabled(false);
                    italicText.setChecked(false); italicText.setEnabled(false);
                }
            }
        });

        addOnClickBtn = addShapePopupView.findViewById(R.id.addOnClick);
        addOnEnterBtn = addShapePopupView.findViewById(R.id.addOnEnter);
        addOnDropBtn = addShapePopupView.findViewById(R.id.addOnDrop);
        // set the above buttons!
        // when a button is clicked, it add the corresponding onClick/onEnter/onDrop script to
        // newShape, using the strings for the four target destination
        setAddScriptBtns();


        editOnClickBtn = addShapePopupView.findViewById(R.id.editOnClick);
        editOnEnterBtn = addShapePopupView.findViewById(R.id.editOnEnter);
        editOnDropBtn = addShapePopupView.findViewById(R.id.editOnDrop);
        setEditScriptBtns();

        // refer to: https://developer.android.com/guide/fragments/communicate#pass-between-fragments
        getParentFragmentManager().setFragmentResultListener("deleteAScriptKey", this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle bundle) {
                // We use a String here, but any type that can be put in a Bundle is supported
                String event = bundle.getString("event");
                Integer indexToDelete = bundle.getInt("indexToDelete");
                String shapeDropOnMe = bundle.getString("shapeDropOnMe");
                // Do something with the result
                newShape.deleteExistingScript(event, indexToDelete, shapeDropOnMe);
            }
        });

        saveShapeBtn = addShapePopupView.findViewById(R.id.saveShapeBtn);
        cancelBtn = addShapePopupView.findViewById(R.id.cancelShapeBtn);

        saveShapeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("A new shape is saved by the user");
                visibleCheck = visibility.isChecked();
                movableCheck = movability.isChecked();
                String shapeName = thisShapeName.getText().toString();
                // set to the default name if the user doesn't give a name
                if (shapeName.equals("")) {
                    // if the user does not specify a name, give the newShape a default name
                    shapeName = giveDefaultName(shapeNames);
                    thisShapeName.setText(shapeName);
                }
                else if (isRepeatedShapeName(shapeName)) {
                    Toast.makeText(requireContext(), "Shape Name already taken!", Toast.LENGTH_SHORT).show();
                    return;
                }
                String textContent = textInput.getText().toString();
                // what if textContent == ""?? -- then it is not of Class text.
                String textFontSizeString = textSizeInput.getText().toString();
                float textFontSize;
                if (textClass.isChecked()) {
                    if (textFontSizeString.equals("")) {
                        textFontSize = DEFAULTFONTSIZE;
                    }
                    else {
                        textFontSize = Float.parseFloat(textFontSizeString);
                    }
                }
                else {
                    // ELSE, textFontSize would be default -- not sure if this is correct.
                    textFontSize = DEFAULTFONTSIZE;
                }

                boldCheck = boldText.isChecked();
                italicCheck = italicText.isChecked();

                newShape.setShapeName(shapeName);
                newShape.setIsVisible(visibleCheck);
                newShape.setIsMovable(movableCheck);
                newShape.setImageName(selectedImageName);
                newShape.setText(textContent);
                newShape.setTextFont(textFontSize);
                newShape.setBold(boldCheck);
                newShape.setItalic(italicCheck);

                // update the script
                // if the shape's script contains the old shapeName, update it to the new shapeName
                if (!shapeName.equals(originalShapeName) && newShape.getScript() != null) {
                    // need to clear the effects of newShape since setScript() will write to them.
                    newShape.onClickEffects = new ArrayList<>();
                    newShape.onEnterEffects = new ArrayList<>();
                    newShape.onDropEffects= new HashMap<>();
                    newShape.setScript(newShape.getScript().replaceAll(originalShapeName, shapeName));
                }
                // if there is a "$this" in the script, substitute it with the current shapeName
                String shapeScript = updateScriptContainSelf(newShape.getScript(), shapeName);
                System.out.println("on save, updated script: " + shapeScript);
                newShape.onClickEffects = new ArrayList<>();
                newShape.onEnterEffects = new ArrayList<>();
                newShape.onDropEffects= new HashMap<>();
                newShape.setScript(shapeScript);

                // TODO: ZJ - I added this for a test
                if (!newShape.getIsText()) {
                    if (newShape.getIsImage()) {
                        if (newShape.getImageName().equals("carrot")) {
                            newShape.setWidth(168.0f);
                            newShape.setHeight(200.0f);
                        } else if (newShape.getImageName().equals("carrot2")) {
                            // TODO:
                            newShape.setWidth(309.0f);
                            newShape.setHeight(326.0f);
                        } else if (newShape.getImageName().equals("death")) {
                            newShape.setWidth(505.0f);
                            newShape.setHeight(540.0f);
                        } else if (newShape.getImageName().equals("duck")) {
                            newShape.setWidth(230.0f);
                            newShape.setHeight(150.0f);
                        } else if (newShape.getImageName().equals("door")) {
                            newShape.setWidth(300.0f);
                            newShape.setHeight(680.0f);
                        } else if (newShape.getImageName().equals("fire")) {
                            // TODO:
                            newShape.setWidth(580.0f);
                            newShape.setHeight(475.0f);
                        } else if (newShape.getImageName().equals("mystic")) {
                            newShape.setWidth(300.0f);
                            newShape.setHeight(390.0f);
                        }

                    } else {
                        // TODO: do whatever if it is a rect
                        newShape.setWidth(200.0f);
                        newShape.setHeight(200.0f);
                    }
                } else {
                    // TODO: do whatever if it is a text
                    newShape.setWidth(200.0f);
                    newShape.setHeight(200.0f);
                }
                // newShape.setTop(20.0f);
                // ---------------------------------

                switch (selectedImageName) {
                    case "carrot":
                        newShape.setShapeBitmap(carrotDrawable.getBitmap());
                        break;
                    case "carrot2":
                        newShape.setShapeBitmap(carrot2Drawable.getBitmap());
                        break;
                    case "death":
                        newShape.setShapeBitmap(deathDrawable.getBitmap());
                        break;
                    case "door":
                        newShape.setShapeBitmap(doorDrawable.getBitmap());
                        break;
                    case "duck":
                        newShape.setShapeBitmap(duckDrawable.getBitmap());
                        break;
                    case "fire":
                        newShape.setShapeBitmap(fireDrawable.getBitmap());
                        break;
                    case "mystic":
                        newShape.setShapeBitmap(mysticDrawable.getBitmap());
                        break;
                }

                addShapeDialogListener.sendInput(mode, newShape);

                String toast_success = shapeName + " added to game!";
                Toast.makeText(requireContext(), toast_success, Toast.LENGTH_SHORT).show();
                getDialog().dismiss();
                // TODO: if need additional error checking??
            }
        });

        Dialog dialog = builder.create();
        setCancelButtonListener(cancelBtn, dialog);
        // setSaveShapeButtonListener(saveShapeBtn, dialog);

        return dialog;
    }

    /*
    Script helper function -- checks if the current script includes a $this, if so, substitute it with the current shape name.
     */
    private String updateScriptContainSelf(String originalScript, String shapeName) {
        if (originalScript == null){
            return "";
        }
        String target = "\\$this";
        String result = originalScript.replaceAll(target, shapeName);
        return  result;
    }

    /*
    Helper - given a list of shapeNames that already existed in the current game, naming a new shape like "shape2", "shape15"...
     */
    private String giveDefaultName(ArrayList<String> shapeNames){
        int n = shapeNames.size();
        String name = "shape" + n;
        while (shapeNames.contains(name)) {
            n++;
            name = "shape" + n;
        }
        return name;
    }

    /*
    Refer to: https://stackoverflow.com/questions/52745909/custom-cancel-button-in-fragments-alertdialogs-click-event-not-handled
     */
    private void setCancelButtonListener(Button button, final Dialog dialog) {
        // System.out.println(button);
        button.setOnClickListener( new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Add Shape Dialog was cancelled by the user");
                dialog.cancel();
            }
        });
    }

//    private void setSaveShapeButtonListener(Button button, final Dialog dialog) {
//        // System.out.println(button);
//        button.setOnClickListener( new Button.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                System.out.println("A new shape is saved by the user");
//                visibleCheck = visibility.isChecked();
//        });
//    }

    /*
    error checking of shape name -- no same name across this game
     */
    private boolean isRepeatedShapeName(String shapeName) {
        for (String existedName : shapeNames ) {
            if (shapeName.equals(existedName)) {
                return true;
            }
        }
        for (String preMapName : preMapShapeNames) {
            if (shapeName.equals(preMapName)) {
                return true;
            }
        }
        return false;
    }

    private void setSpinners() {

        ArrayAdapter<String> arrayAdapterImage = new ArrayAdapter<>(this.getActivity(),
                android.R.layout.simple_spinner_item,
                DEFAULTIMAGES);
        arrayAdapterImage.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        imageSpinner.setAdapter(arrayAdapterImage);
        imageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedImageName = adapterView.getItemAtPosition(i).toString();
                // draw preview image in the ImageView!!
                switch (selectedImageName) {
                    case "carrot":
                        imagePreview.setImageResource(R.drawable.carrot);
                        break;
                    case "carrot2":
                        imagePreview.setImageResource(R.drawable.carrot2);
                        break;
                    case "death":
                        imagePreview.setImageResource(R.drawable.death);
                        break;
                    case "door":
                        imagePreview.setImageResource(R.drawable.door);
                        break;
                    case "duck":
                        imagePreview.setImageResource(R.drawable.duck);
                        break;
                    case "fire":
                        imagePreview.setImageResource(R.drawable.fire);
                        break;
                    case "mystic":
                        imagePreview.setImageResource(R.drawable.mystic);
                        break;
                    case "":
                        imagePreview.setImageResource(R.color.gray);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                selectedImageName = "";
            }
        });

        ArrayAdapter<String> arrayAdapterSound = new ArrayAdapter<>(this.getActivity(),
                android.R.layout.simple_spinner_item,
                DEFAULTSOUNDS);
        arrayAdapterSound.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        onClickPlaySpinner.setAdapter(arrayAdapterSound);
        onClickPlaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onClickPlayScript = adapterView.getItemAtPosition(i).toString();
                if (onClickPlayScript.equals("")) {
                    onClickPlayScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onClickPlayScript = null;
            }
        });

        onEnterPlaySpinner.setAdapter(arrayAdapterSound);
        onEnterPlaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onEnterPlayScript = adapterView.getItemAtPosition(i).toString();
                if (onEnterPlayScript.equals("")) {
                    onEnterPlayScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onEnterPlayScript = null;
            }
        });

        onDropPlaySpinner.setAdapter(arrayAdapterSound);
        onDropPlaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onDropPlayScript = adapterView.getItemAtPosition(i).toString();
                if (onDropPlayScript.equals("")) {
                    onDropPlayScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onDropPlayScript = null;
            }
        });

        ArrayAdapter<String> arrayAdapterPages = new ArrayAdapter<>(this.getActivity(),
                android.R.layout.simple_spinner_item,
                pageNames);
        arrayAdapterPages.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        onClickGoToSpinner.setAdapter(arrayAdapterPages);
        onClickGoToSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onClickGoToScript = adapterView.getItemAtPosition(i).toString();
                if (onClickGoToScript.equals("")) {
                    onClickGoToScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onClickGoToScript = null;
            }
        });

        onEnterGoToSpinner.setAdapter(arrayAdapterPages);
        onEnterGoToSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onEnterGoToScript = adapterView.getItemAtPosition(i).toString();
                if (onEnterGoToScript.equals("")) {
                    onEnterGoToScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onEnterGoToScript = null;
            }
        });

        onDropGoToSpinner.setAdapter(arrayAdapterPages);
        onDropGoToSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onDropGoToScript = adapterView.getItemAtPosition(i).toString();
                if (onDropGoToScript.equals("")) {
                    onDropGoToScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onDropGoToScript = null;
            }
        });

        ArrayAdapter<String> arrayAdapterShapes = new ArrayAdapter<>(this.getActivity(),
                android.R.layout.simple_spinner_item,
                shapeNames);
        arrayAdapterShapes.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        objectAcceptedSpinner.setAdapter(arrayAdapterShapes);
        objectAcceptedSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedObjectAcceptedName = adapterView.getItemAtPosition(i).toString();
                if (selectedObjectAcceptedName.equals("")) {
                    selectedObjectAcceptedName = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                selectedObjectAcceptedName = null;
            }
        });

        ArrayList<String> shapeNamesIncludingSelf = (ArrayList<String>) shapeNames.clone();
        shapeNamesIncludingSelf.add("$this");
        ArrayAdapter<String> arrayAdapterShapesIncludingSelf = new ArrayAdapter<>(this.getActivity(),
                android.R.layout.simple_spinner_item,
                shapeNamesIncludingSelf);
        arrayAdapterShapesIncludingSelf.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        onClickShowSpinner.setAdapter(arrayAdapterShapesIncludingSelf);
        onClickShowSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onClickShowScript = adapterView.getItemAtPosition(i).toString();
                if (onClickShowScript.equals("")) {
                    onClickShowScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onClickShowScript = null;
            }
        });

        onClickHideSpinner.setAdapter(arrayAdapterShapesIncludingSelf);
        onClickHideSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onClickHideScript = adapterView.getItemAtPosition(i).toString();
                if (onClickHideScript.equals("")) {
                    onClickHideScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onClickHideScript = null;
            }
        });

        onEnterShowSpinner.setAdapter(arrayAdapterShapesIncludingSelf);
        onEnterShowSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onEnterShowScript = adapterView.getItemAtPosition(i).toString();
                if (onEnterShowScript.equals("")) {
                    onEnterShowScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onEnterShowScript = null;
            }
        });

        onEnterHideSpinner.setAdapter(arrayAdapterShapesIncludingSelf);
        onEnterHideSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onEnterHideScript = adapterView.getItemAtPosition(i).toString();
                if (onEnterHideScript.equals("")) {
                    onEnterHideScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onEnterHideScript = null;
            }
        });

        onDropShowSpinner.setAdapter(arrayAdapterShapesIncludingSelf);
        onDropShowSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onDropShowScript = adapterView.getItemAtPosition(i).toString();
                if (onDropShowScript.equals("")) {
                    onDropShowScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onDropShowScript = null;
            }
        });

        onDropHideSpinner.setAdapter(arrayAdapterShapesIncludingSelf);
        onDropHideSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                onDropHideScript = adapterView.getItemAtPosition(i).toString();
                if (onDropHideScript.equals("")) {
                    onDropHideScript = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                onDropHideScript = null;
            }
        });
    }

    private void setAddScriptBtns() {
        addOnClickBtn.setOnClickListener(new View.OnClickListener() {
            /*
            Add a list of GoTo/Play/Hide/Show targets <String GoTo, String Play, String Hide, String Show>
            into the temporary storage of onClick Script targets.
             */
            @Override
            public void onClick(View view) {
                if (onClickGoToScript == null && onClickPlayScript == null && onClickHideScript == null && onClickShowScript == null){
                    Toast.makeText(requireContext(),"Cannot add empty script!", Toast.LENGTH_SHORT).show();
                }
                else if (movability.isChecked()) {
                    Toast.makeText(requireContext(),"Cannot add onClick script to movable item!", Toast.LENGTH_SHORT).show();
                }
                else {
                    newShape.addScript("onClick", onClickGoToScript, onClickPlayScript, onClickHideScript, onClickShowScript, null);
                }
            }
        });

        addOnEnterBtn.setOnClickListener(new View.OnClickListener() {
            /*
            Add a list of GoTo/Play/Hide/Show targets <String GoTo, String Play, String Hide, String Show>
            into the temporary storage of onEnter Script targets.
             */
            @Override
            public void onClick(View view) {
                if (onEnterGoToScript == null && onEnterPlayScript == null && onEnterHideScript == null && onEnterShowScript == null){
                    Toast.makeText(requireContext(),"Cannot add empty script!", Toast.LENGTH_SHORT).show();
                }
                else {
                    newShape.addScript("onEnter", onEnterGoToScript, onEnterPlayScript, onEnterHideScript, onEnterShowScript, null);
                }
            }
        });

        addOnDropBtn.setOnClickListener(new View.OnClickListener() {
            /*
            Add a list of GoTo/Play/Hide/Show targets <String GoTo, String Play, String Hide, String Show>
            that correspond to a specific Accepted Objects dropping on this shape (shapeDropOnMe as the key of the map)
            into the temporary storage (a hashmap) of onDrop Script targets.
             */
            @Override
            public void onClick(View view) {
                // if there's an acceptable shape
                if (selectedObjectAcceptedName != null) {
                    System.out.println("selecedObjectAcceptedName is not null!");
                    if (onDropGoToScript == null && onDropPlayScript == null && onDropHideScript == null && onDropShowScript == null){
                        Toast.makeText(requireContext(),"Cannot add empty script!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        newShape.addScript("onDrop", onDropGoToScript, onDropPlayScript, onDropHideScript, onDropShowScript, selectedObjectAcceptedName);
                    }
                }
                else {
                    Toast.makeText(requireContext(), "Must select a shape to accept!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setEditScriptBtns() {
        editOnClickBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditScriptDialogFragment editScriptDialog = new EditScriptDialogFragment();
                Bundle bundle = new Bundle();
                bundle.putString("event", "onClick");
                bundle.putSerializable("onClickEffects", newShape.onClickEffects);
                bundle.putSerializable("onEnterEffects", newShape.onEnterEffects);
                bundle.putSerializable("onDropEffects", newShape.onDropEffects);
                bundle.putString("shapeDropOnMe", selectedObjectAcceptedName);
                editScriptDialog.setArguments(bundle);
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction(); // got this line from: https://stackoverflow.com/questions/16540186/show-dialogfragment-from-another-dialogfragment
                editScriptDialog.show(transaction,"Edit onClick Script");
            }
        });

        editOnEnterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditScriptDialogFragment editScriptDialog = new EditScriptDialogFragment();
                Bundle bundle = new Bundle();
                bundle.putString("event", "onEnter");
                bundle.putSerializable("onClickEffects", newShape.onClickEffects);
                bundle.putSerializable("onEnterEffects", newShape.onEnterEffects);
                bundle.putSerializable("onDropEffects", newShape.onDropEffects);
                bundle.putString("shapeDropOnMe", selectedObjectAcceptedName);
                editScriptDialog.setArguments(bundle);
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                editScriptDialog.show(transaction,"Edit onEnter Script");
            }
        });

        editOnDropBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedObjectAcceptedName == null) {
                    Toast.makeText(requireContext(),"Must select an accepted object to proceed!", Toast.LENGTH_SHORT).show();
                }
                else {
                    EditScriptDialogFragment editScriptDialog = new EditScriptDialogFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("event", "onDrop");
                    bundle.putSerializable("onClickEffects", newShape.onClickEffects);
                    bundle.putSerializable("onEnterEffects", newShape.onEnterEffects);
                    bundle.putSerializable("onDropEffects", newShape.onDropEffects);
                    bundle.putString("shapeDropOnMe", selectedObjectAcceptedName);
                    editScriptDialog.setArguments(bundle);
                    // System.out.println("edit on drop btn: onDropEffects" + newShape.onDropEffects);
                    FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                    editScriptDialog.show(transaction,"Edit onDrop Script");
                }
            }
        });
    }

}
