package edu.stanford.cs108.win23_cs108_bunnyworld;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.fragment.app.FragmentManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EditScriptDialogFragment extends AppCompatDialogFragment {

    Toast toast;

    // we want to receive these 5 variables from AddShapeDialogFragment
    private String event;
    private ArrayList<ArrayList<String>> onClickEffects;
    private ArrayList<ArrayList<String>> onEnterEffects;
    private HashMap<String, ArrayList<ArrayList<String>>> onDropEffects;     // of the specific accepted object: shapeDropOnMe
    private String shapeDropOnMe;

    //public OnInputListener editScriptDialogListener;

    TextView scriptTitle;
    LinearLayout acceptObjectLayout;
    TextView acceptedObjectName;
    Spinner scriptSelectionSpinner;
    Button cancelBtn;
    Button deleteScriptBtn;
    String scriptToDelete = "";
    Integer indexToDelete;

//    public interface OnInputListener {
//        void sendDeleteInput(String event, int index, String shapeDropOnMe);
//
//    }

//    @Override
//    public void onAttach(Context context)
//    {
//        super.onAttach(context);
//        try {
//            editScriptDialogListener
//                    = (EditScriptDialogFragment.OnInputListener)getTargetFragment();
//        }
//        catch (ClassCastException e) {
//            Log.e("EditShapeDialogFragment", "onAttach: ClassCastException: "
//                    + e.getMessage());
//        }
//    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        // this dialog will get the event name (onCLick/onEnter/onDrop), and the corresponding actions list
        // of that event
        event = getArguments().getString("event");
        // System.out.println("onCreate event: " + event);
        onClickEffects = (ArrayList<ArrayList<String>>) getArguments().getSerializable("onClickEffects");
        onEnterEffects = (ArrayList<ArrayList<String>>) getArguments().getSerializable("onEnterEffects");
        onDropEffects = (HashMap<String, ArrayList<ArrayList<String>>>) getArguments().getSerializable("onDropEffects");
        shapeDropOnMe = getArguments().getString("shapeDropOnMe");

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Delete A Script!");
        final View editScriptPopupView = getLayoutInflater().inflate(R.layout.edit_script_popup, null);
        builder.setView(editScriptPopupView);

        scriptTitle = (TextView) editScriptPopupView.findViewById(R.id.scriptTitle);
        setScriptTitle(event);

        // display the accepted object only when we are selecting the onDrop scripts
        acceptedObjectName = (TextView) editScriptPopupView.findViewById(R.id.acceptObjectOfInterest);
        acceptObjectLayout = (LinearLayout) editScriptPopupView.findViewById(R.id.acceptObjectField);
        if (event == "onDrop") {
            acceptObjectLayout.setVisibility(View.VISIBLE);
            acceptedObjectName.setText(shapeDropOnMe);
        }
        else {
            acceptObjectLayout.setVisibility(View.GONE);
        }

        // set the spinner!
        scriptSelectionSpinner = (Spinner) editScriptPopupView.findViewById(R.id.scriptSelection);
        setScriptSelectionSpinner(event, onClickEffects,onEnterEffects, onDropEffects);

        cancelBtn = (Button) editScriptPopupView.findViewById(R.id.cancelScriptBtn);
        deleteScriptBtn = (Button) editScriptPopupView.findViewById(R.id.deleteScriptBtn);

        Dialog dialog = builder.create();

        deleteScriptBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("An " + event + " script is delete by the user");
                // refer to: https://developer.android.com/guide/fragments/communicate#pass-between-fragments
                Bundle result = new Bundle();
                result.putString("event", event);
                result.putInt("indexToDelete", indexToDelete);
                result.putString("shapeDropOnMe", shapeDropOnMe);
                getParentFragmentManager().setFragmentResult("deleteAScriptKey", result);
                // editScriptDialogListener.sendDeleteInput(event, indexToDelete, shapeDropOnMe);
                // ↑ the previous setDeleteScriptBtnListener(deleteScriptBtn, dialog) cannot do this since it cannot access the listener
                // from a separate function since the input argument is a Dialog, not the EditScriptDialogFragment which has access to
                // the listener.

                String toast_success = event + ": " + scriptToDelete + " deleted!";
                toast = Toast.makeText(requireContext(), toast_success, Toast.LENGTH_SHORT);
                toast.show();
                getDialog().dismiss();
            }
        });

        setCancelButtonListener(cancelBtn, dialog);
        // setDeleteScriptBtnListener(deleteScriptBtn, dialog);

        return dialog;
    }

    private void setCancelButtonListener(Button button, final Dialog dialog) {
        // System.out.println(button);
        button.setOnClickListener( new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Edit Script Dialog was cancelled by the user");
                dialog.cancel();
            }
        });
    }

//    /*
//    On Button click, update the Actions based on the event passed into this dialog and the scriptToDelete selected
//    by the user.
//     */
//    private void setDeleteScriptBtnListener(Button button, final Dialog dialog) {
//        button.setOnClickListener( new Button.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                System.out.println("An " + event + " script is delete by the user");
//                editScriptDialogListener.sendDeleteInput(event, indexToDelete, shapeDropOnMe);
//
//                String toast_success = event + ": " + scriptToDelete + " deleted!";
//                toast = Toast.makeText(requireContext(), toast_success, Toast.LENGTH_SHORT);
//                toast.show();
//                dialog.cancel();
//            }
//        });
//    }


    /*
    Set the script title in the dialog, depending on the onClick/onEnter/onDrop event.
     */
    private void setScriptTitle(String event) {
        switch(event) {
            case "onClick":
                scriptTitle.setText("onClick Scripts");
                break;
            case "onEnter":
                scriptTitle.setText("onEnter Scripts");
                break;
            case "onDrop":
                scriptTitle.setText("onDrop Scripts");
                break;
        }
    }

    private void setScriptSelectionSpinner(String event, ArrayList<ArrayList<String>> onClickEffects,
                                           ArrayList<ArrayList<String>> onEnterEffects, HashMap<String, ArrayList<ArrayList<String>>> onDropEffects) {
        switch (event) {
            case "onClick":
                // ArrayList<String> onClickScripts = scriptSpinnerHelper(onClickEffects);                  <--- obsolete
                ArrayAdapter<String> arrayAdapterOnClick = new ArrayAdapter<String>(this.getActivity(),
                        android.R.layout.simple_spinner_item,
                        scriptSpinnerHelper(onClickEffects));
                arrayAdapterOnClick.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
                scriptSelectionSpinner.setAdapter(arrayAdapterOnClick);
                break;

            case "onEnter":
                ArrayAdapter<String> arrayAdapterOnEnter = new ArrayAdapter<String>(this.getActivity(),
                        android.R.layout.simple_spinner_item,
                        scriptSpinnerHelper(onEnterEffects));
                arrayAdapterOnEnter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
                scriptSelectionSpinner.setAdapter(arrayAdapterOnEnter);
                break;

            case "onDrop":
                ArrayAdapter<String> arrayAdapterOnDrop;
                if (onDropEffects.get(shapeDropOnMe) == null) {
                    arrayAdapterOnDrop = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item,
                            scriptSpinnerHelper(new ArrayList<>()));
                }
                else{
                    arrayAdapterOnDrop = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item,
                            scriptSpinnerHelper(onDropEffects.get(shapeDropOnMe)));
                }
                arrayAdapterOnDrop.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
                scriptSelectionSpinner.setAdapter(arrayAdapterOnDrop);
                break;
        }
        scriptSelectionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                scriptToDelete = adapterView.getItemAtPosition(i).toString();       // for debug use, if we want to print the selected script
                indexToDelete = i;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                scriptToDelete = "";
                indexToDelete = -1;
            }
        });
    }

    /*
    Helper -- compose the inner list <String GoTo, String Play, String Hide, String Show> into a string
     */
    private ArrayList<String> scriptSpinnerHelper(ArrayList<ArrayList<String>> actions) {
        ArrayList<String> result = new ArrayList<>();
        for (ArrayList<String> action : actions) {
            StringBuilder newScript = new StringBuilder();
            // special character "&" added to help string splitting & increase readability
            for (int i = 0; i < action.size(); i++) {
                newScript.append(action.get(i));
                if (i < action.size() - 1) {
                    newScript.append(",");
                }
            }
            result.add(newScript.toString());
        }
        return result;
    }

}
