package edu.stanford.cs108.win23_cs108_bunnyworld;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GamePlayActivity extends AppCompatActivity {

    SQLiteDatabase db;
    private String gamePlayed;              // this one we get from MainActivity
    customViewPlayer myViewPlayer;
    private Map<String, List<Shape>> gameMap_EachPageANDItsShapeList= new HashMap<String, List<Shape>>();
    private List<Shape> shapeList_CurrentPage;
    private List<Shape> shapeList_InPossessionArea = new ArrayList<>();
    Shape shapeCurrentlyDealingWith;
    String script_shapeCurrentlyDealingWith;
    List<String> bks;
    MediaPlayer mp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.player);

        Bundle bundle = getIntent().getExtras();
        gamePlayed = bundle.getString("gameToBePlayed");

        // IMPORTANT: get the view!!!
        myViewPlayer = findViewById(R.id.playerView);
        bks = new ArrayList<>();
        bks.add("sky");
        bks.add("forest");
        bks.add("night");
        bks.add("stanford");
        mp = new MediaPlayer();

        loadGame(gamePlayed);

        MotionEvent event = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, 10, 1080, 0);
        myViewPlayer.dispatchTouchEvent(event);         // click once to identify objects in possession area
        // Toast.makeText(getApplicationContext(), "New click initiated", Toast.LENGTH_SHORT).show();
    }

    private void loadGame(String gameToBePlayed) {
        db = openOrCreateDatabase("ShapesDB", MODE_PRIVATE,null);

        // Get all pages of this game:
        String pageCmd = "SELECT pageName FROM Shapes where gameName = '" + gameToBePlayed + "';";
        Cursor pageCursor = db.rawQuery( pageCmd,null);
        while (pageCursor.moveToNext()) {
            String pageNow = pageCursor.getString(0);

            // Get all shapes in this page of this game
            String shapeCmd = "SELECT * FROM Shapes where gameName = " + "'"+
                    gameToBePlayed + "'" + " AND pageName = " + "'"+ pageNow + "'"+ ";";
            Cursor shapeCursor = db.rawQuery( shapeCmd,null);
            List<Shape> shapesNow = new ArrayList<Shape>();
            while (shapeCursor.moveToNext()) {
                String shapeName = shapeCursor.getString(0);
                String imageName = shapeCursor.getString(1);
                String text = shapeCursor.getString(2);
                float x = shapeCursor.getFloat(3);
                float y = shapeCursor.getFloat(4);
                float width = shapeCursor.getFloat(5);
                float height = shapeCursor.getFloat(6);
                Integer isPossesion_ = shapeCursor.getInt(7);
                Integer isBold_ = shapeCursor.getInt(8);
                Integer isItalic_ = shapeCursor.getInt(9);
                Integer movable_ = shapeCursor.getInt(10);
                Integer isVisible_ = shapeCursor.getInt(11);
                Integer fontSize = shapeCursor.getInt(12);
                String script = shapeCursor.getString(13);
                String pageName = shapeCursor.getString(14);
                Boolean isPossesion = isPossesion_ == 0 ? false : true;
                Boolean isBold = isBold_ == 0 ? false : true;
                Boolean isItalic = isItalic_ == 0 ? false : true;
                Boolean movable = movable_ == 0 ? false : true;
                Boolean isVisible = isVisible_ == 0 ? false : true;
                Shape shapeNow = new Shape(shapeName, pageName, isVisible, movable, imageName, text, fontSize, isBold, isItalic);
                shapeNow.setLeft(x);
                shapeNow.setTop(y);
                shapeNow.setWidth(width);
                shapeNow.setHeight(height);
                shapeNow.setScript(script);
                shapeNow.setInPossessionArea(isPossesion);
                if (bks.contains(imageName)) shapesNow.add(0, shapeNow);
                else shapesNow.add(shapeNow);
            }
            gameMap_EachPageANDItsShapeList.put(pageNow, shapesNow);
        }
        shapeList_CurrentPage = gameMap_EachPageANDItsShapeList.get("Page1");
        myViewPlayer.drawCurrentPage(shapeList_CurrentPage,true, "Page1");
    }

    // --------------------------- TODO: HERE ---------------------------
    public void receiveShapeFromCustomViewPlayer(Shape a, String trigger) {
        shapeCurrentlyDealingWith = a;
        script_shapeCurrentlyDealingWith = shapeCurrentlyDealingWith.getScript();
        if (trigger.equals("onEnter")) {
            runScript(shapeCurrentlyDealingWith, "onEnter");
        } else if (trigger.equals("onClick")){
            runScript(shapeCurrentlyDealingWith, "onClick");
        } else{
            runScript(shapeCurrentlyDealingWith, trigger);
        }
    }

    // --------------------------- TODO: HERE ---------------------------
    public void fetchAllShapes_InPossessionArea_FromCustomViewPlayer(List<Shape> allShapesInPossession_List_incoming) {
        shapeList_InPossessionArea.clear();
        for (Shape j: allShapesInPossession_List_incoming) {
            shapeList_InPossessionArea.add(j);
        }
    }


    // --------------------------- TODO: HERE ---------------------------

    private void runScript(Shape shapeCurrentlyDealingWith, String trigger) {
        if(trigger.equals("onClick")) {
            // System.out.println("runScript, trigger: onClick, shapeCurrentlyDealingWith: " + shapeCurrentlyDealingWith.getShapeName());
            List<String> shapeCurrentlyDealingWith_OnClickClauses = shapeCurrentlyDealingWith.getInfoMap().get("onClick");
            executeOnClickEffects(shapeCurrentlyDealingWith_OnClickClauses);
        } else if(trigger.equals("onEnter")){
            // System.out.println("runScript, trigger: onEnter, shapeCurrentlyDealingWith: " + shapeCurrentlyDealingWith.getShapeName());
            List<String> shapeCurrentlyDealingWith_OnEnterClauses = shapeCurrentlyDealingWith.getInfoMap().get("onEnter");
            executeOnEnterEffects(shapeCurrentlyDealingWith_OnEnterClauses);
        } else {     // trigger could be "onDrop carrot"
            // System.out.println("runScript, trigger: " + trigger + ", shapeCurrentlyDealingWith: " + shapeCurrentlyDealingWith.getShapeName());
            List<String> shapeCurrentlyDealingWith_OnDropClauses = shapeCurrentlyDealingWith.getInfoMap().get(trigger);
            executeOnDropEffects(shapeCurrentlyDealingWith_OnDropClauses);
        }




    }

    private String findPageNameOfThisShape(String targetShapeName) {
        for (Map.Entry<String, List<Shape>> eachPageAndItsShapeList: gameMap_EachPageANDItsShapeList.entrySet()) {
            String p = eachPageAndItsShapeList.getKey();
            List<Shape> sl = eachPageAndItsShapeList.getValue();
            for (Shape i: sl) {
                if (i.getShapeName().equals(targetShapeName)) {
                    return p;
                }
            }
        }
        return " ";
    }

    private void executeOnClickEffects(List<String> shapeCurrentlyDealingWith_OnClickClauses) {
        if (shapeCurrentlyDealingWith_OnClickClauses == null
                || shapeCurrentlyDealingWith_OnClickClauses.size() < 1
                || !shapeCurrentlyDealingWith.getIsVisible()
                || shapeCurrentlyDealingWith.getTop() >= 1040.f) {

            return;
        }
        for(String clause: shapeCurrentlyDealingWith_OnClickClauses){
            String verb = clause.split(" ")[0];
            String noun = clause.split(" ")[1];

            if (verb.equals("goto")) {
                System.out.println("executeOnClickEffects, goto page " + noun);
                String targetPageName = noun;
                if (gameMap_EachPageANDItsShapeList.get(targetPageName) == null) {
                    return;
                }
                List<Shape> shapeList_TargetPage = gameMap_EachPageANDItsShapeList.get(targetPageName);

                List<Shape> finalGuy = new ArrayList<>();
                finalGuy.addAll(shapeList_TargetPage);
                finalGuy.addAll(shapeList_InPossessionArea);

                myViewPlayer.drawCurrentPage(finalGuy, true, targetPageName);
                for (Shape s: shapeList_InPossessionArea) {
                    fixThisShapeToItsNewlyArrivedPage(s, targetPageName);
                }

            } else if (verb.equals("show") || verb.equals("hide")) {
                System.out.println("executeOnClickEffects, hide or show shape " + noun);
                String shapeName_NeedToHide = noun;

                // Find it and set its field isVisible to true
                String shapeName_NeedToHide_PageName = findPageNameOfThisShape(shapeName_NeedToHide);
                List<Shape> shapeName_NeedToHide_PageName_ShapeList = gameMap_EachPageANDItsShapeList.get(shapeName_NeedToHide_PageName);
                for (Shape i: shapeName_NeedToHide_PageName_ShapeList) {
                    if (i.getShapeName().equals(shapeName_NeedToHide)) {
                        if (verb.equals("show")) {
                            i.setIsVisible(true);
                        } else {
                            i.setIsVisible(false);
                        }
                        break;
                    }
                }
                String original_PageName = findPageNameOfThisShape(shapeCurrentlyDealingWith.getShapeName());
                List<Shape> original_PageName_ShapeList = gameMap_EachPageANDItsShapeList.get(original_PageName);

                List<Shape> finalGuy = new ArrayList<>();
                finalGuy.addAll(original_PageName_ShapeList);
                finalGuy.addAll(shapeList_InPossessionArea);

                myViewPlayer.drawCurrentPage(finalGuy, false, original_PageName);
                for (Shape s: shapeList_InPossessionArea) {
                    fixThisShapeToItsNewlyArrivedPage(s, original_PageName);
                }

            } else if (verb.equals("play")) {
                if (myViewPlayer.soundLibrary.containsKey(noun)) {
                    mp = MediaPlayer.create(getApplicationContext(), myViewPlayer.soundLibrary.get(noun));
                    mp.start();
                    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            mp.release();
                        }
                    });
                } else {
                    Toast toast = Toast.makeText(getApplicationContext(), "Play sound '" + noun + "' not found", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }

        }

    }

    private void executeOnEnterEffects(List<String> shapeCurrentlyDealingWith_OnEnterClauses) {
        if (shapeCurrentlyDealingWith_OnEnterClauses == null
                || shapeCurrentlyDealingWith_OnEnterClauses.size() < 1
                || !shapeCurrentlyDealingWith.getIsVisible()
                || shapeCurrentlyDealingWith.getTop() >= 1040.f) {

            return;
        }
        // execute all clauses
        for (String clause: shapeCurrentlyDealingWith_OnEnterClauses){
            String verb = clause.split(" ")[0];
            String noun = clause.split(" ")[1];

            if (verb.equals("goto")) {
                String targetPageName = noun;
                if (gameMap_EachPageANDItsShapeList.get(targetPageName) == null) {
                    return;
                }
                List<Shape> shapeList_TargetPage = gameMap_EachPageANDItsShapeList.get(targetPageName);

                List<Shape> finalGuy = new ArrayList<>();
                finalGuy.addAll(shapeList_TargetPage);
                finalGuy.addAll(shapeList_InPossessionArea);

                myViewPlayer.drawCurrentPage(finalGuy, true, targetPageName);
                for (Shape s: shapeList_InPossessionArea) {
                    fixThisShapeToItsNewlyArrivedPage(s, targetPageName);
                }

            } else if (verb.equals("show") || verb.equals("hide")) {
                String shapeName_NeedToHide = noun;

                // Find it and set its field isVisible to true
                String shapeName_NeedToHide_PageName = findPageNameOfThisShape(shapeName_NeedToHide);
                List<Shape> shapeName_NeedToHide_PageName_ShapeList = gameMap_EachPageANDItsShapeList.get(shapeName_NeedToHide_PageName);
                for (Shape i: shapeName_NeedToHide_PageName_ShapeList) {
                    if (i.getShapeName().equals(shapeName_NeedToHide)) {
                        if (verb.equals("show")) {
                            i.setIsVisible(true);
                        } else {
                            i.setIsVisible(false);
                        }
                        break;
                    }
                }
                String original_PageName = findPageNameOfThisShape(shapeCurrentlyDealingWith.getShapeName());
                List<Shape> original_PageName_ShapeList = gameMap_EachPageANDItsShapeList.get(original_PageName);

                List<Shape> finalGuy = new ArrayList<>();
                finalGuy.addAll(original_PageName_ShapeList);
                finalGuy.addAll(shapeList_InPossessionArea);

                myViewPlayer.drawCurrentPage(finalGuy, false, original_PageName);
                for (Shape s: shapeList_InPossessionArea) {
                    fixThisShapeToItsNewlyArrivedPage(s, original_PageName);
                }

            } else if (verb.equals("play")) {
                if (myViewPlayer.soundLibrary.containsKey(noun)) {
                    mp = MediaPlayer.create(getApplicationContext(), myViewPlayer.soundLibrary.get(noun));
                    mp.start();
                    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            mp.release();
                        }
                    });
                } else {
                    Toast toast = Toast.makeText(getApplicationContext(), "Play sound '" + noun + "' not found", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        }





    }

    private void executeOnDropEffects(List<String> shapeCurrentlyDealingWith_OnDropClauses) {
        System.out.println("enter executeOnDropEffects, clauses: " + shapeCurrentlyDealingWith_OnDropClauses);
        if (shapeCurrentlyDealingWith_OnDropClauses == null
                || shapeCurrentlyDealingWith_OnDropClauses.size() < 1
                || !shapeCurrentlyDealingWith.getIsVisible()
                || shapeCurrentlyDealingWith.getTop()>= 1040.f) {
            System.out.println("early exist because: visible: " + shapeCurrentlyDealingWith.getIsVisible() +
                    ", inPossession: " + (Boolean) (shapeCurrentlyDealingWith.getTop()>= 1040.f));
            return;
        }
        // execute all clauses
        for (String clause: shapeCurrentlyDealingWith_OnDropClauses){
            System.out.println(clause);
            String verb = clause.split(" ")[0];
            String noun = clause.split(" ")[1];
            if (verb.equals("goto")) {
                String targetPageName = noun;
                if (gameMap_EachPageANDItsShapeList.get(targetPageName) == null) {
                    return;
                }
                List<Shape> shapeList_TargetPage = gameMap_EachPageANDItsShapeList.get(targetPageName);

                List<Shape> finalGuy = new ArrayList<>();
                finalGuy.addAll(shapeList_TargetPage);
                finalGuy.addAll(shapeList_InPossessionArea);

                myViewPlayer.drawCurrentPage(finalGuy, false, targetPageName);
                for (Shape s: shapeList_InPossessionArea) {
                    fixThisShapeToItsNewlyArrivedPage(s, targetPageName);
                }

            } else if (verb.equals("show") || verb.equals("hide")) {
                String shapeName_NeedToHide = noun;
                System.out.println("Need to hide " + shapeName_NeedToHide);
                // Find it and set its field isVisible to true
                String shapeName_NeedToHide_PageName = findPageNameOfThisShape(shapeName_NeedToHide);
                List<Shape> shapeName_NeedToHide_PageName_ShapeList = gameMap_EachPageANDItsShapeList.get(shapeName_NeedToHide_PageName);
                for (Shape i: shapeName_NeedToHide_PageName_ShapeList) {
                    if (i.getShapeName().equals(shapeName_NeedToHide)) {
                        if (verb.equals("show")) {
                            i.setIsVisible(true);
                        } else {
                            i.setIsVisible(false);
                        }
                        break;
                    }
                }
                String original_PageName = findPageNameOfThisShape(shapeCurrentlyDealingWith.getShapeName());
                List<Shape> original_PageName_ShapeList = gameMap_EachPageANDItsShapeList.get(original_PageName);

                List<Shape> finalGuy = new ArrayList<>();
                finalGuy.addAll(original_PageName_ShapeList);
                finalGuy.addAll(shapeList_InPossessionArea);

                myViewPlayer.drawCurrentPage(finalGuy, false, original_PageName);
                for (Shape s: shapeList_InPossessionArea) {
                    fixThisShapeToItsNewlyArrivedPage(s, original_PageName);
                }

            } else if (verb.equals("play")) {
                if (myViewPlayer.soundLibrary.containsKey(noun)) {
                    mp = MediaPlayer.create(getApplicationContext(), myViewPlayer.soundLibrary.get(noun));
                    mp.start();
                    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            mp.release();
                        }
                    });
                } else {
                    Toast toast = Toast.makeText(getApplicationContext(), "Play sound '" + noun + "' not found", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        }
    }

    public void fixThisShapeToItsNewlyArrivedPage(Shape s, String targetPageNameToFixAt) {
        System.out.println("target page: " + targetPageNameToFixAt + " shape:" + s.getShapeName() + " its currentPage: " + s.getPageName());
        String originalPageName = s.getPageName();
        s.setPageName(targetPageNameToFixAt);

//        for (Map.Entry<String, List<Shape>> eachPair: gameMap_EachPageANDItsShapeList.entrySet()) {
//            String eachPageName = eachPair.getKey();
//            List<Shape> eachPage_shapeList = eachPair.getValue();
//            if (eachPageName.equals(originalPageName)) {
//                eachPage_shapeList.remove(s);
//            }
//        }

        gameMap_EachPageANDItsShapeList.get(originalPageName).remove(s);
        gameMap_EachPageANDItsShapeList.get(targetPageNameToFixAt).add(s);

    }

}
