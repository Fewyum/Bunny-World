package edu.stanford.cs108.win23_cs108_bunnyworld;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class customViewEditor extends View {

    // Instance variables:
    String pageName;
    List<Shape> shapeList;



    String gameNameOfThisPage;

    SQLiteDatabase db;
    BitmapDrawable carrotDrawable;
    BitmapDrawable carrot2Drawable;
    BitmapDrawable deathDrawable;
    BitmapDrawable doorDrawable;
    BitmapDrawable duckDrawable;
    BitmapDrawable fireDrawable;
    BitmapDrawable mysticDrawable;
    BitmapDrawable skyDrawable;
    BitmapDrawable forestDrawable;
    BitmapDrawable nightDrawable;
    BitmapDrawable stanfordDrawable;

    MediaPlayer mpCarrotCarrotCarrot;
    MediaPlayer mpEvilLaugh;
    MediaPlayer mpFire;
    MediaPlayer mpHooray;
    MediaPlayer mpMunch;
    MediaPlayer mpMunching;
    MediaPlayer mpWoof;
    Canvas canvas;
    Paint greyPaint;
    Paint blackPaint;
    Paint greenPaint_edge;
    Paint bluePaint_edge;
    Paint myPaint;
    List<String> bks = new ArrayList<>(Arrays.asList("sky", "night", "forest", "stanford"));


    // Constructor:
    @RequiresApi(api = Build.VERSION_CODES.S)
    @SuppressLint("UseCompatLoadingForDrawables")
    public customViewEditor(Context context, AttributeSet attrs) {
        super(context, attrs);

        carrotDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.carrot,getContext().getTheme());
        carrot2Drawable = (BitmapDrawable) getResources().getDrawable(R.drawable.carrot2,getContext().getTheme());
        deathDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.death,getContext().getTheme());
        doorDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.door,getContext().getTheme());
        duckDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.duck,getContext().getTheme());
        fireDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.fire,getContext().getTheme());
        mysticDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.mystic,getContext().getTheme());
        skyDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.sky,getContext().getTheme());
        forestDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.forest,getContext().getTheme());
        nightDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.night,getContext().getTheme());
        stanfordDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.stanford,getContext().getTheme());


        MediaPlayer mpCarrotCarrotCarrot = MediaPlayer.create(getContext(),R.raw.carrotcarrotcarrot);
        MediaPlayer mpEvilLaugh = MediaPlayer.create(getContext(),R.raw.evillaugh);
        MediaPlayer mpFire = MediaPlayer.create(getContext(),R.raw.fire);
        MediaPlayer mpHooray = MediaPlayer.create(getContext(),R.raw.hooray);
        MediaPlayer mpMunch = MediaPlayer.create(getContext(),R.raw.munch);
        MediaPlayer mpMunching = MediaPlayer.create(getContext(),R.raw.munching);
        MediaPlayer mpWoof = MediaPlayer.create(getContext(),R.raw.woof);

        greyPaint = new Paint();
        greyPaint.setColor(Color.GRAY);
        blackPaint = new Paint();
        blackPaint.setColor(Color.BLACK);
        greenPaint_edge = new Paint();
        greenPaint_edge.setColor(Color.GREEN);
        greenPaint_edge.setStyle(Paint.Style.STROKE);
        greenPaint_edge.setStrokeWidth(15.0f);
        bluePaint_edge = new Paint();
        bluePaint_edge.setColor(Color.BLUE);
        bluePaint_edge.setStyle(Paint.Style.STROKE);
        bluePaint_edge.setStrokeWidth(15.0f);

        myPaint = new Paint();
        canvas = new Canvas();
    }


    int textWidth;
    int textHeight;

    // --------------------------- Method 1, the overridden onDraw() --------------------------------- //
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // System.out.println("yes");
        if (shapeList == null) return;
        if (shapeList.isEmpty()){
            canvas.drawColor(Color.WHITE);
            return;
        }
        for (Shape curShape: shapeList) {

            if (curShape.getIsVisible()) {
                // Check1: if the shape is a text, draw its text
                if (curShape.getIsText()) {
                    int[] textColorIntRGBValues = curShape.getTextColorIntRGBValues();
                    myPaint.setColor(Color.rgb(textColorIntRGBValues[0], textColorIntRGBValues[1], textColorIntRGBValues[2]));
                    myPaint.setTextSize(curShape.getTextFont());

                    // Added here
//                    // curShape.setLeft();
//                    curShape.setTop(curShape.getTop() - curShape.getTextFont());
//                    // curShape.setWidth();
                    curShape.setHeight(curShape.getTextFont());
                    // -----------

                    canvas.drawText(curShape.getText(), curShape.getLeft(), curShape.getTop() + curShape.getHeight(), myPaint);
                } else {
                    // Check2: if the shape is an image, draw that image
                    if (curShape.getIsImage()) {
//                        drawCurrentPage(shapeList);
                        canvas.drawBitmap(curShape.getShapeBitmap(), curShape.getLeft(), curShape.getTop(), null);
                    } else {
                        // Check3: if the shape is a rect, draw the gray rectangle
                        if (curShape.getIsRect()) {
                            canvas.drawRect(curShape.getLeft(), curShape.getTop(),
                                    curShape.getLeft() + curShape.getWidth(), curShape.getTop() + curShape.getHeight(), greyPaint);
                        }
                    }
                }
            }

//            if (curShape.getIfHasLittleBlackBox()) {
//                canvas.drawRect(curShape.getLeft() + curShape.getWidth(), curShape.getTop() + curShape.getHeight(),
//                        curShape.getLeft() + curShape.getWidth() + 30.0f, curShape.getTop() + curShape.getHeight() + 30.0f, blackPaint);
//            }

            // If the border should turn green, draw the green border as a stroke
            if (curShape.getIsBorderGreen()) {
                canvas.drawRect(curShape.getLeft(), curShape.getTop(),
                        curShape.getLeft() + curShape.getWidth(), curShape.getTop() + curShape.getHeight(), greenPaint_edge);
            } else if (curShape.getIsBorderBlue()) {
                if (curShape.getIsText()) {

                    // new

                    float LT_x = curShape.getLeft();
                    float LT_y = curShape.getTop() - curShape.getTextFont() + curShape.getHeight();
                    float RB_x = LT_x + curShape.getWidth();
                    float RB_y = LT_y + curShape.getTextFont();

//                    float LT_x = curShape.getLeft();
//                    float LT_y = curShape.getTop();
//                    float RB_x = LT_x + curShape.getWidth();
//                    float RB_y = LT_y + curShape.getTextFont();


                    canvas.drawRect(LT_x, LT_y, RB_x, RB_y, bluePaint_edge);
                } else {
                    canvas.drawRect(curShape.getLeft(), curShape.getTop(),
                            curShape.getLeft() + curShape.getWidth(), curShape.getTop() + curShape.getHeight(), bluePaint_edge);
                }
            }

            if (curShape.getIfHasLittleBlackBox()) {
                canvas.drawRect(curShape.getLeft() + curShape.getWidth(), curShape.getTop() + curShape.getHeight(),
                        curShape.getLeft() + curShape.getWidth() + 30.0f, curShape.getTop() + curShape.getHeight() + 30.0f, blackPaint);
            }
        }
    }

    public void drawCurrentPage(List<Shape> a) {
        if (a == null) return;
        System.out.println(a.size() + "HI");
        for (Shape shape : a) {
            if (shape.getIsImage()) {
                drawScaledShape(shape);

            }
        }
        shapeList = a;
        invalidate();
    }


    // --------------------------- Method 2, the overridden onTouchEvent() --------------------------- //
    Shape hereShape;
    Shape aboutToBeResizedShape;
    float xDiffFixed;
    float yDiffFixed;
    float xInit;
    float yInit;

    @RequiresApi(api = Build.VERSION_CODES.S)
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            float xDown = event.getX();
            float yDown = event.getY();

            hereShape = findTopShapeAtThisLocation(xDown, yDown);
            aboutToBeResizedShape = findTheShapeToBeResized(xDown, yDown);

            if (hereShape != null) {
                deselectAllShapes();
                makeAllBlackBoxDisappear();
                hereShape.setIsBorderBlue(true);
                hereShape.setIfHasLittleBlackBox(true);
                xDiffFixed = xDown - hereShape.getLeft();
                yDiffFixed = yDown - hereShape.getTop();
            } else {
                if (aboutToBeResizedShape == null) {
                    for (Shape everyShape: shapeList) {
                        everyShape.setIsBorderBlue(false);
                        everyShape.setIsBorderGreen(false);
                        everyShape.setIfHasLittleBlackBox(false);
                    }
                    deselectAllShapes();
                    makeAllBlackBoxDisappear();
                } else {
                    xInit = xDown;
                    yInit = yDown;
                }
            }
        } else if (event.getAction() == MotionEvent.ACTION_MOVE) {
            float xInMotion = event.getX();
            float yInMotion = event.getY();

            if (aboutToBeResizedShape == null && hereShape != null) {
                hereShape.setLeft(xInMotion - xDiffFixed);
                hereShape.setTop(yInMotion - yDiffFixed);
                hereShape.setIsBorderBlue(true);
                hereShape.setIfHasLittleBlackBox(true);
            } else if (aboutToBeResizedShape != null && hereShape == null ) {
                float xChanged = xInMotion - (aboutToBeResizedShape.getLeft() + aboutToBeResizedShape.getWidth());
                float yChanged = yInMotion - (aboutToBeResizedShape.getTop() + aboutToBeResizedShape.getHeight());
                if ((aboutToBeResizedShape.getWidth() + xChanged) > 0 && (aboutToBeResizedShape.getHeight() + yChanged) > 0) {
                    aboutToBeResizedShape.setWidth(aboutToBeResizedShape.getWidth() + xChanged);
                    aboutToBeResizedShape.setHeight(aboutToBeResizedShape.getHeight() + yChanged);
                    drawScaledShape(aboutToBeResizedShape);
                    aboutToBeResizedShape.setIsBorderBlue(true);
                    aboutToBeResizedShape.setIfHasLittleBlackBox(true);
                }
            }
        } else if (event.getAction() == MotionEvent.ACTION_UP) {
            if (hereShape != null) {
                if (!bks.contains(hereShape.getImageName())) {
                    if (!hereShape.getIsInPossessionArea()) {
                        if ((hereShape.getTop() + hereShape.getHeight() / 2) > 1040.0f && hereShape.getTop() < 1040.0f) {
                            hereShape.setTop(1040.0f);
                            hereShape.setInPossessionArea(true);
                        } else if ((hereShape.getTop() + hereShape.getHeight() / 2) <= 1040.0f && (hereShape.getTop() + hereShape.getHeight()) >= 1040.0f) {
                            hereShape.setTop(hereShape.getTop() - (hereShape.getTop() + hereShape.getHeight() - 1040.0f));
                        }
                    } else {
                        if ((hereShape.getTop() + hereShape.getHeight() / 2) > 1040.0f && hereShape.getTop() < 1040.0f) {
                            hereShape.setTop(1040.0f);
                        } else if ((hereShape.getTop() + hereShape.getHeight() / 2) <= 1040.0f && (hereShape.getTop() + hereShape.getHeight()) >= 1040.0f) {
                            hereShape.setTop(hereShape.getTop() - (hereShape.getTop() + hereShape.getHeight() - 1040.0f));
                            hereShape.setInPossessionArea(false);
                        }
                    }
                }
            }
        }

        // TODO: I added here

        ((EditorActivity)this.getContext()).getSelected(hereShape);  // if hereShape is null, what will be passed to customViewPlayer is null
        ((EditorActivity)this.getContext()).renewShape(shapeList);
        // ------------------

        invalidate();
        return true;
    }


    // --------------------------- Other Helper Methods --------------------------- //
    public void drawScaledShape(Shape shape) {
        if (shape.getIsImage()) {
            String itsImageName = shape.getImageName();
            int addedShape = getResources().getIdentifier(itsImageName, "drawable", getContext().getPackageName());
            BitmapDrawable drawableAdded = (BitmapDrawable) getResources().getDrawable(addedShape);
            Bitmap bitmapAdded = drawableAdded.getBitmap();
            if ((int) shape.getWidth() != 0 && (int) shape.getHeight() != 0) {
                Bitmap bitmapScale = Bitmap.createScaledBitmap(bitmapAdded, (int) shape.getWidth(), (int) shape.getHeight(), false);
                shape.setShapeBitmap(bitmapScale);
            }
        } else if (shape.getIsText()) {
            shape.setTextFont(shape.getWidth() / 10);
        }
        invalidate();
    }

    private Shape findTheShapeToBeResized(float a, float b) {
        for (Shape i: shapeList) {
            float xRB = i.getLeft() + i.getWidth();
            float yRB = i.getTop() + i.getHeight();
            boolean isXInRange = a >= xRB && a <= xRB + 30.0f;
            boolean isYInRange = b >= yRB && b <= yRB + 30.0f;
            if (isXInRange && isYInRange) {
                return i;
            }
        }
        return null;
    }

    private Shape findTopShapeAtThisLocation(float myX, float myY) {
        for (int i = shapeList.size() - 1; i >= 0; i--) {
            Shape curShape = shapeList.get(i);
            float x1 = curShape.getLeft();
            float y1 = curShape.getTop();
            float x2 = x1 + curShape.getWidth();
            float y2 = y1 + curShape.getHeight();
            boolean isXinRange = (myX >= x1 && myX <= x2);
            boolean isYinRange = (myY >= y1 && myY <= y2);;
            if (isXinRange && isYinRange) {
                return curShape;
            }
        }
        return null;
    }

    // Helper functions used elsewhere:

    private Set<Shape> findPossibleTargetShapes(Shape thisShape) {
        String thisShapeName = thisShape.getShapeName();
        Set<Shape> result = new HashSet<>();

        for (Shape shape: shapeList) {
            List<String> onDropClauses = thisShape.getInfoMap().get("on drop");
            if (onDropClauses != null && !onDropClauses.isEmpty()) {
                for (String clause: onDropClauses) {
                    String a = clause.split(" ")[0];
                    if (a.equals(thisShapeName)) {
                        result.add(shape);
                    }
                }
            }
        }

        return result;
    }

    private boolean ifTwoShapesAreOverlapping(Shape sp1, Shape sp2) {
        float sp1_left = sp1.getLeft();
        float sp1_top = sp1.getTop();
        float sp1_width = sp1.getWidth();
        float sp1_height = sp1.getHeight();
        float sp2_left = sp2.getLeft();
        float sp2_top = sp2.getTop();
        float sp2_width = sp2.getWidth();
        float sp2_height = sp2.getHeight();

        boolean isSp1LTPointInSp2 = ifThisPointIsWithinThisShape(sp1_left, sp1_top, sp2);
        boolean isSp1LBPointInSp2 = ifThisPointIsWithinThisShape(sp1_left, sp1_top + sp1_height, sp2);
        boolean isSp1RTPointInSp2 = ifThisPointIsWithinThisShape(sp1_left + sp1_width, sp1_top, sp2);
        boolean isSp1RBPointInSp2 = ifThisPointIsWithinThisShape(sp1_left + sp1_width, sp1_top + sp1_height, sp2);
        boolean isSp2LTPointInSp1 = ifThisPointIsWithinThisShape(sp2_left, sp2_top, sp1);
        boolean isSp2LBPointInSp1 = ifThisPointIsWithinThisShape(sp2_left, sp2_top + sp2_height, sp1);
        boolean isSp2RTPointInSp1 = ifThisPointIsWithinThisShape(sp2_left + sp2_width, sp2_top, sp1);
        boolean isSp2RBPointInSp1 = ifThisPointIsWithinThisShape(sp2_left + sp2_width, sp2_top + sp2_height, sp1);

        return (isSp1LTPointInSp2 || isSp1LBPointInSp2 || isSp1RTPointInSp2 || isSp1RBPointInSp2)
                || (isSp2LTPointInSp1 || isSp2LBPointInSp1 || isSp2RTPointInSp1 || isSp2RBPointInSp1);
    }

    private boolean ifThisPointIsWithinThisShape(float x, float y, Shape sp) {
        boolean isXInRange = x >= sp.getLeft() && x <= sp.getLeft() + sp.getWidth();
        boolean isYInRange = y >= sp.getTop() && y <= sp.getTop() + sp.getHeight();
        return isXInRange && isYInRange;
    }

    private void deselectAllShapes() {
        for (Shape i: shapeList) {
            i.setIsBorderBlue(false);
        }
    }

    private void makeAllBlackBoxDisappear() {
        for (Shape i: shapeList) {
            i.setIfHasLittleBlackBox(false);
        }
    }

}
