package edu.stanford.cs108.win23_cs108_bunnyworld;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    SQLiteDatabase db;
    List<String> games;
    public Spinner spinnerGame;
    public String itemGame;
    BitmapDrawable carrotDrawable;
    BitmapDrawable carrot2Drawable;
    BitmapDrawable deathDrawable;
    BitmapDrawable doorDrawable;
    BitmapDrawable duckDrawable;
    BitmapDrawable fireDrawable;
    BitmapDrawable mysticDrawable;
    BitmapDrawable failDrawable;
    Bitmap carrot;
    Bitmap carrot2;
    Bitmap death;
    Bitmap door;
    Bitmap duck;
    Bitmap fire;
    Bitmap mystic;
    Bitmap fail;
    String carrotString, carrot2String, deathString, doorString, duckString, fireString, mysticString, failString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = openOrCreateDatabase("ShapesDB",MODE_PRIVATE,null);
        // check if the cities table already exist in db
        Cursor tablesCursor = db.rawQuery(
                "SELECT * FROM sqlite_master WHERE type='table' AND name='Shapes';",
                null);
        if (tablesCursor.getCount() == 0) {
            // setup the table
            resetDatabase();
        }
        // setupDatabaseToOnlyHaveDefaultGame();
        //resetDatabase();
        // get images
        carrotDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.carrot);
        carrot2Drawable = (BitmapDrawable) getResources().getDrawable(R.drawable.carrot2);
        deathDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.death);
        doorDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.door);
        duckDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.duck);
        fireDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.fire);
        mysticDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.mystic);
        failDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.fail);
        // get bitmaps
        carrot = carrotDrawable.getBitmap();
        carrot2 = carrot2Drawable.getBitmap();
        death = deathDrawable.getBitmap();
        door = doorDrawable.getBitmap();
        duck = duckDrawable.getBitmap();
        fire = fireDrawable.getBitmap();
        mystic = mysticDrawable.getBitmap();
        fail = failDrawable.getBitmap();

        // get string
//        carrotString = BitmapCovert.convert(carrot);
//        carrot2String = BitmapCovert.convert(carrot2);
//        deathString = BitmapCovert.convert(death);
//        doorString = BitmapCovert.convert(door);
//        duckString = BitmapCovert.convert(duck);
//        fireString = BitmapCovert.convert(fire);
//        mysticString = BitmapCovert.convert(mystic);
//        failString = BitmapCovert.convert(fail);

        // spinner
        games = new ArrayList<>();
        games = gameList();      // cannot be here
//        games.add("DefaultGame");
//        // to test reset db
//        games.add("test test");
//        games.add("test test test");
        spinnerGame = findViewById(R.id.selectgame);
        spinnerGame.setOnItemSelectedListener(this);
        ArrayAdapter adGame = new ArrayAdapter(this,
                android.R.layout.simple_spinner_item,
                games);
        spinnerGame.setAdapter(adGame);
        adGame.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // "PLAY GAME" button and its onClickListener
        Button btnPlayGame = (Button)findViewById(R.id.playgame);
        btnPlayGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //resetDatabase();
                Intent intent = new Intent(MainActivity.this, GamePlayActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("gameToBePlayed", itemGame);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        // "EDIT GAME" button and its onClickListener
        Button btnEditGame = (Button)findViewById(R.id.editgame);
        btnEditGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, EditorActivity.class);
                // System.out.println("new intent created");
                Bundle bundle = new Bundle();
                bundle.putString("gameToBeEditted", itemGame);
                intent.putExtras(bundle);
                // System.out.println("bundle created");
                // System.out.println("gameToBeEditted" + gameName);
                startActivity(intent);
            }
        });

        // "NEW GAME" button and its onClickListener
        Button btnNewGame = (Button)findViewById(R.id.newgame);
        btnNewGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // startActivity(new Intent(MainActivity.this, EditorActivity.class));

                Intent intent = new Intent(MainActivity.this, EditorActivity.class);
                System.out.println("new intent created");
                Bundle bundle = new Bundle();
                bundle.putString("gameToBeEditted", "");
                intent.putExtras(bundle);
                System.out.println("bundle created");
                // games = gameList();
                // System.out.println("gameToBeEditted" + gameName);
                startActivity(intent);
                // newGame();

            }
        });


        // "RESET DB" button and its onClickListener
        Button btnResetDB = (Button)findViewById(R.id.resetdb);
        btnResetDB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // startActivity(new Intent(MainActivity.this, EditorActivity.class));
                resetDatabase();
                System.out.println("DB just reset");
            }
        });


        // "DELETE GAME" button and its onClickListener
        Button btnDeleteGame = (Button)findViewById(R.id.deletegame);
        btnDeleteGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: find the gameName from pull-down menu, and delete all shapes of this game from DB
                deleteGame(itemGame);
            }
        });

        // "LOAD DEFAULT GAME" button and its onClickListener
        Button btnLoadDefaultGame = (Button)findViewById(R.id.loaddfgame);
        btnLoadDefaultGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: put string "defaultGame" into pull-down space
                spinnerGame.setSelection(0);
            }
        });
    }

    private void setupDatabaseToOnlyHaveDefaultGame() {
        db = openOrCreateDatabase("ShapesDB",MODE_PRIVATE,null);
        Cursor tablesCursor = db.rawQuery(
                "SELECT * FROM sqlite_master WHERE type='table' AND name='Shapes';",
                null);
        if (tablesCursor.getCount() == 0) {
            String setupStr = "CREATE TABLE Shapes ("
                    + "shapeName TEXT,"
                    + "imageName TEXT,"
                    + "text TEXT,"
                    + "x REAL,"
                    + "y REAL,"
                    + "width REAL,"
                    + "height REAL,"
                    + "inPossesion INTEGER,"
                    + "inBold INTEGER,"
                    + "inItalic INTEGER,"
                    + "moveable INTEGER,"
                    + "isVisible INTEGER,"
                    + "fontSize REAL,"
                    + "script TEXT,"
                    + "pageName TEXT,"
                    + "gameName TEXT,"
//                    + "shapeBitmap TEXT,"
                    + "_id INTEGER PRIMARY KEY AUTOINCREMENT"
                    + ");";
            db.execSQL(setupStr);
        }
        addDefaultGameIntoDatabase();
    }

    private void resetDatabase() {
        db = openOrCreateDatabase("ShapesDB", MODE_PRIVATE,null);
        db.execSQL("DROP TABLE IF EXISTS Shapes;");
        setupDatabaseToOnlyHaveDefaultGame();
        Toast.makeText(getApplicationContext(),"DB was just reset",Toast.LENGTH_SHORT).show();
    }

    public void deleteGame(String gameName) {
        db = openOrCreateDatabase("GamesDB", MODE_PRIVATE,null);
        String cmd = "DROP TABLE IF EXISTS name = ";
        cmd += gameName;
        db.execSQL(cmd);
    }

    public void playGame (View view) {
        // yuanlai
        String nameGame = itemGame;
        Intent intent = new Intent(this, GamePlayActivity.class);
        startActivity(intent);


    }

    public void editGame (String gameName) {
        Intent intent = new Intent(this, EditorActivity.class);
        // System.out.println("new intent created");
        Bundle bundle = new Bundle();
        bundle.putString("gameToBeEditted", itemGame);
        intent.putExtras(bundle);
        // System.out.println("bundle created");
        // System.out.println("gameToBeEditted" + gameName);
        startActivity(intent);
    }
    public void newGame () {
        Intent intent = new Intent(this, EditorActivity.class);
        startActivity(intent);
        // when start a new game, the game name would be an empty string.
    }

    private List<String> gameList() {
        db = openOrCreateDatabase("ShapesDB", MODE_PRIVATE,null);
        List<String> gameNames = new ArrayList<>();
        gameNames.add("DefaultGame");
        Cursor cursor = db.rawQuery( "SELECT gameName FROM Shapes",null);
        HashSet<String> myName = new HashSet<>();
        while (cursor.moveToNext()) {
            myName.add(cursor.getString(0));
        }
        for (String name: myName) {
            if (!name.equals("DefaultGame")) {
                gameNames.add(name);
            }
        }
        return gameNames;
    }

    private void addDefaultGameIntoDatabase() {
        //Text1 on page 1
        String text1_1cmd = "INSERT INTO Shapes VALUES ('" +
                "text1_1" + "', '" +
                "" + "', '" +
                "Welcome to Bunny World!" + "', '" +
                "600"+ "', '" +
                "150" + "', '" +
                "1150" + "', '" +
                "450" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "100" + "', '" +
                "" + "', '" +
                "Page1" + "', '" +
//                "" + "', '" +
                "DefaultGame" + "',  NULL);";
        //Text2 on page 1
        String text1_2cmd = "INSERT INTO Shapes VALUES ('" +
                "text1_2" + "', '" +
                "" + "', '" +
                "You are in a maze in a twisty little passages, all like" + "', '" +
                "500"+ "', '" +
                "275" + "', '" +
                "1365" + "', '" +
                "600" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "60" + "', '" +
                "" + "', '" +
                "Page1" + "', '" +
//                "" + "', '" +
                "DefaultGame" + "',  NULL);";
        //Door 1 on page 1
        String door1_1cmd = "INSERT INTO Shapes VALUES ('" +
                "door1_1" + "', '" +
                "door" + "', '" +
                "" + "', '" +
                "390"+ "', '" +
                "340" + "', '" +
                "300" + "', '" +
                "680" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "on click goto Page2;" + "', '" +
                "Page1" + "', '" +
//                doorString + "', '" +
                "DefaultGame" + "',  NULL);";
        //Door 2 on page 1
        String door1_2cmd = "INSERT INTO Shapes VALUES ('" +
                "door1_2" + "', '" +
                "door" + "', '" +
                "" + "', '" +
                "1030"+ "', '" +
                "340" + "', '" +
                "300" + "', '" +
                "680" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "on click goto Page3;" + "', '" +
                "Page1" + "', '" +
//                doorString + "', '" +
                "DefaultGame" + "',  NULL);";
        //Door 3 on page 1
        String door1_3cmd = "INSERT INTO Shapes VALUES ('" +
                "door1_3" + "', '" +
                "door" + "', '" +
                "" + "', '" +
                "1670"+ "', '" +
                "340" + "', '" +
                "300" + "', '" +
                "680" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "on click goto Page4;" + "', '" +
                "Page1" + "', '" +
//                doorString + "', '" +
                "DefaultGame" + "',  NULL);";
        db.execSQL(text1_1cmd);
        db.execSQL(text1_2cmd);
        db.execSQL(door1_1cmd);
        db.execSQL(door1_2cmd);
        db.execSQL(door1_3cmd);

        //Bunny 1 on page 2
        String bunny2_1cmd = "INSERT INTO Shapes VALUES ('" +
                "bunny2_1" + "', '" +
                "mystic" + "', '" +
                "" + "', '" +
                "1360"+ "', '" +
                "100" + "', '" +
                "300" + "', '" +
                "390" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "on click play munching hide carrot3_1;on enter show door1_2;on drop duck2_1 goto Page6" + "', '" +
                "Page2" + "', '" +
//                mysticString + "', '" +
                "DefaultGame" + "',  NULL);";
        //Text1 on page 2
        String text2_1cmd = "INSERT INTO Shapes VALUES ('" +
                "text2_1" + "', '" +
                "" + "', '" +
                "Mystic Bunny - Rub my tummy for a big surprise!" + "', '" +
                "800"+ "', '" +
                "600" + "', '" +
                "1350" + "', '" +
                "750" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "70" + "', '" +
                "" + "', '" +
                "Page2" + "', '" +
//                "" + "', '" +
                "DefaultGame" + "',  NULL);";
        //Door1 on page 2
        String door2_1cmd = "INSERT INTO Shapes VALUES ('" +
                "door2_1" + "', '" +
                "door" + "', '" +
                "" + "', '" +
                "320"+ "', '" +
                "250" + "', '" +
                "300" + "', '" +
                "680" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "on click goto Page1;" + "', '" +
                "Page2" + "', '" +
//                doorString + "', '" +
                "DefaultGame" + "',  NULL);";
        // Duck1 on page 2
        String duck2_1cmd = "INSERT INTO Shapes VALUES ('" +
                "duck2_1" + "', '" +
                "duck" + "', '" +
                "" + "', '" +
                "850"+ "', '" +
                "170" + "', '" +
                "230" + "', '" +
                "150" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "1" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "Page2" + "', '" +
//                duckString + "', '" +
                "DefaultGame" + "',  NULL);";
        db.execSQL(text2_1cmd);
        db.execSQL(door2_1cmd);
        db.execSQL(bunny2_1cmd);
        db.execSQL(duck2_1cmd);


        // fire 1 on page 3
        String fire3_1cmd = "INSERT INTO Shapes VALUES ('" +
                "fire3_1" + "', '" +
                "fire" + "', '" +
                "" + "', '" +
                "250"+ "', '" +
                "300" + "', '" +
                "580" + "', '" +
                "475" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "on enter play fire;" + "', '" +
                "Page3" + "', '" +
//                fireString + "', '" +
                "DefaultGame" + "',  NULL);";
        //text 1 on page 3
        String text3_1cmd = "INSERT INTO Shapes VALUES ('" +
                "text3_1" + "', '" +
                "" + "', '" +
                "Eek!! Fire room. Run away!" + "', '" +
                "150"+ "', '" +
                "225" + "', '" +
                "1350" + "', '" +
                "700" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "70" + "', '" +
                "" + "', '" +
                "Page3" + "', '" +
//                "" + "', '" +
                "DefaultGame" + "',  NULL);";
        //Carrot 1 on page 3
        String carrot3_1cmd = "INSERT INTO Shapes VALUES ('" +
                "carrot3_1" + "', '" +
                "carrot" + "', '" +
                "" + "', '" +
                "1200"+ "', '" +
                "400" + "', '" +
                "168" + "', '" +
                "200" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "1" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "Page3" + "', '" +
//                fireString + "', '" +
                "DefaultGame" + "',  NULL);";

        //Door1 on page 3
        String door3_1cmd = "INSERT INTO Shapes VALUES ('" +
                "door3_1" + "', '" +
                "door" + "', '" +
                "" + "', '" +
                "1800"+ "', '" +
                "200" + "', '" +
                "300" + "', '" +
                "680" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "on click goto Page2;" + "', '" +
                "Page3" + "', '" +
//                doorString + "', '" +
                "DefaultGame" + "',  NULL);";
        // db.execSQL(text3_1cmd);
        db.execSQL(door3_1cmd);
        db.execSQL(fire3_1cmd);
        db.execSQL(carrot3_1cmd);


        //Door1 on page 4
        String door4_1cmd = "INSERT INTO Shapes VALUES ('" +
                "door4_1" + "', '" +
                "door" + "', '" +
                "" + "', '" +
                "220"+ "', '" +
                "150" + "', '" +
                "300" + "', '" +
                "680" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "on click goto Page1;" + "', '" +
                "Page4" + "', '" +
//                doorString + "', '" +
                "DefaultGame" + "',  NULL);";
        //Door2 on page 4
        String door4_2cmd = "INSERT INTO Shapes VALUES ('" +
                "door4_2" + "', '" +
                "door" + "', '" +
                "" + "', '" +
                "1920"+ "', '" +
                "150" + "', '" +
                "300" + "', '" +
                "680" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "on click goto Page5;" + "', '" +
                "Page4" + "', '" +
//                doorString + "', '" +
                "DefaultGame" + "',  NULL);";
        //Death Bunny1 on page 4
        String death4_1cmd = "INSERT INTO Shapes VALUES ('" +
                "death4_1" + "', '" +
                "death" + "', '" +
                "" + "', '" +
                "900"+ "', '" +
                "250" + "', '" +
                "505" + "', '" +
                "540" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "on enter play evillaugh;on " +
                "drop carrot3_1 hide " +
                "carrot3_1 play munching hide death4_1 show door4_2;" +
                "on click play evillaugh;" + "', '" +
                "Page4" + "', '" +
//                deathString + "', '" +
                "DefaultGame" + "',  NULL);";
        //Text1 on page 4
        String text4_1cmd = "INSERT INTO Shapes VALUES ('" +
                "text4_1" + "', '" +
                "" + "', '" +
                "You must appease the Bunny of Death!" + "', '" +
                "420"+ "', '" +
                "950" + "', '" +
                "1920" + "', '" +
                "500" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "80" + "', '" +
                "" + "', '" +
                "Page4" + "', '" +
//                "" + "', '" +
                "DefaultGame" + "',  NULL);";
        db.execSQL(text4_1cmd);
        db.execSQL(door4_1cmd);
        db.execSQL(door4_2cmd);
        db.execSQL(death4_1cmd);


        //Carrot1 on page 5
        String carrot5_1cmd = "INSERT INTO Shapes VALUES ('" +
                "carrot5_1" + "', '" +
                "carrot" + "', '" +
                "" + "', '" +
                "300"+ "', '" +
                "300" + "', '" +
                "168" + "', '" +
                "200" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "Page5" + "', '" +
//                carrotString + "', '" +
                "DefaultGame" + "',  NULL);";
        String carrot5_2cmd = "INSERT INTO Shapes VALUES ('" +
                "carrot5_2" + "', '" +
                "carrot" + "', '" +
                "" + "', '" +
                "1100"+ "', '" +
                "600" + "', '" +
                "168" + "', '" +
                "200" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "Page5" + "', '" +
//                carrotString + "', '" +
                "DefaultGame" + "',  NULL);";
        String carrot5_3cmd = "INSERT INTO Shapes VALUES ('" +
                "carrot5_3" + "', '" +
                "carrot" + "', '" +
                "" + "', '" +
                "1900"+ "', '" +
                "100" + "', '" +
                "168" + "', '" +
                "200" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "Page5" + "', '" +
//                carrotString + "', '" +
                "DefaultGame" + "',  NULL);";
        String text5_1cmd = "INSERT INTO Shapes VALUES ('" +
                "text5_1" + "', '" +
                "" + "', '" +
                "You win!! Yayyyy!" + "', '" +
                "740"+ "', '" +
                "300" + "', '" +
                "1280" + "', '" +
                "450" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "120" + "', '" +
                "on enter play hooray" + "', '" +
                "Page5" + "', '" +
//                "" + "', '" +
                "DefaultGame" + "',  NULL);";
        db.execSQL(carrot5_1cmd);
        db.execSQL(carrot5_2cmd);
        db.execSQL(carrot5_3cmd);
        db.execSQL(text5_1cmd);
        //Fail1 on page6
        String fail6_1cmd = "INSERT INTO Shapes VALUES ('" +
                "fail6_1" + "', '" +
                "fail" + "', '" +
                "" + "', '" +
                "50"+ "', '" +
                "50" + "', '" +
                "2460" + "', '" +
                "1700" + "', '" +
                "0" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "" + "', '" +
                "" + "', '" +
                "Page6" + "', '" +
//                failString + "', '" +
                "DefaultGame" + "',  NULL);";
        String text6_1cmd = "INSERT INTO Shapes VALUES ('" +
                "text6_1" + "', '" +
                "" + "', '" +
                "GAME OVER" + "', '" +
                "450"+ "', '" +
                "600" + "', '" +
                "1280" + "', '" +
                "450" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "0" + "', '" +
                "1" + "', '" +
                "300" + "', '" +
                "" + "', '" +
                "Page6" + "', '" +
//                "" + "', '" +
                "DefaultGame" + "',  NULL);";
        db.execSQL(fail6_1cmd);
        db.execSQL(text6_1cmd);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        itemGame = spinnerGame.getSelectedItem().toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void reNewList(List<String> a) {

    }

    /*
    When the main activity is back to foreground, update the spinner
     */
    @Override
    protected void onResume() {
        super.onResume();
        games = gameList();
        ArrayAdapter adGame = new ArrayAdapter(this,
                android.R.layout.simple_spinner_item,
                games);
        spinnerGame.setAdapter(adGame);
        adGame.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    }
}
